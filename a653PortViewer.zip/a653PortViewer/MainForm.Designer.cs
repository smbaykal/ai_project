namespace A653PortViewer;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();

        // Menu strip
        _menuStrip = new MenuStrip();
        _fileMenu = new ToolStripMenuItem("File");
        _loadDllMenuItem = new ToolStripMenuItem("Load DLL...");
        _loadDllMenuItem.ShortcutKeys = Keys.Control | Keys.O;
        _loadDllMenuItem.Click += LoadDllMenuItem_Click;
        _fileMenu.DropDownItems.Add(_loadDllMenuItem);
        _menuStrip.Items.Add(_fileMenu);

        // Timer
        _refreshTimer = new System.Windows.Forms.Timer(components);
        _refreshTimer.Interval = 250;
        _refreshTimer.Tick += RefreshTimer_Tick;

        // Filter text box
        _filterPanel = new Panel { Dock = DockStyle.Top, Height = 30, Padding = new Padding(4, 4, 4, 2) };
        _txtFilter = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Filter channels..." };
        _txtFilter.TextChanged += TxtFilter_TextChanged;
        _filterPanel.Controls.Add(_txtFilter);

        // Tree view
        _treeView = new TreeView();
        _treeView.Dock = DockStyle.Fill;
        _treeView.CheckBoxes = true;
        _treeView.HideSelection = false;
        _treeView.ShowNodeToolTips = true;
        _treeView.AfterCheck += TreeView_AfterCheck;
        _treeView.BeforeCheck += TreeView_BeforeCheck;
        _treeView.NodeMouseDoubleClick += TreeView_NodeMouseDoubleClick;

        // Unsubscribe All button (docked bottom, above status strip)
        _btnUnsubscribeAll = new Button
        {
            Text = "Unsubscribe All",
            Dock = DockStyle.Bottom,
            Height = 28,
            FlatStyle = FlatStyle.System
        };
        _btnUnsubscribeAll.Click += BtnUnsubscribeAll_Click;

        // Status strip
        _statusStrip = new StatusStrip();
        _statusLabelSubscribed = new ToolStripStatusLabel("Subscribed: 0/0 channels") { Spring = false };
        _statusLabelAction = new ToolStripStatusLabel("") { Spring = true, TextAlign = System.Drawing.ContentAlignment.MiddleRight };
        _statusStrip.Items.Add(_statusLabelSubscribed);
        _statusStrip.Items.Add(_statusLabelAction);

        // Assemble form
        Controls.Add(_treeView);
        Controls.Add(_filterPanel);
        Controls.Add(_btnUnsubscribeAll);
        Controls.Add(_menuStrip);
        Controls.Add(_statusStrip);
        MainMenuStrip = _menuStrip;

        Text = "A653 Port Viewer";
        Size = new Size(360, 600);
        StartPosition = FormStartPosition.CenterScreen;
    }

    private MenuStrip _menuStrip;
    private ToolStripMenuItem _fileMenu;
    private ToolStripMenuItem _loadDllMenuItem;
    private Panel _filterPanel;
    private TextBox _txtFilter;
    private TreeView _treeView;
    private System.Windows.Forms.Timer _refreshTimer;
    private Button _btnUnsubscribeAll;
    private StatusStrip _statusStrip;
    private ToolStripStatusLabel _statusLabelSubscribed;
    private ToolStripStatusLabel _statusLabelAction;
}
