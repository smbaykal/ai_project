using System.Collections;
using System.Reflection;

namespace A653PortViewer.Reflection;

/// <summary>
/// Loads assemblies where channel metadata and message field constraints are declared as
/// static const fields (e.g., <c>public const string Direction = "source";</c>).
/// This is the convention used by the a653CSharpCodegen code generator.
/// </summary>
public sealed class ConstMsgLoader : IMsgLoader
{
    public List<PartitionNode> Load(Assembly assembly)
    {
        var partitions = new List<PartitionNode>();

        foreach (var (type, name, ns) in MsgAssemblyLoader.DiscoverPartitions(assembly))
        {
            var partition = new PartitionNode
            {
                Name = name,
                Namespace = ns,
                Type = type
            };

            foreach (var channelType in MsgAssemblyLoader.DiscoverChannelTypes(type))
            {
                var channel = BuildChannelNode(channelType);
                if (channel is not null)
                {
                    partition.Channels.Add(channel);
                }
            }

            partitions.Add(partition);
        }

        return partitions;
    }

    private static ChannelNode? BuildChannelNode(Type channelType)
    {
        var directionField = channelType.GetField("Direction", BindingFlags.Public | BindingFlags.Static);
        var portNameField = channelType.GetField("PortName", BindingFlags.Public | BindingFlags.Static);
        var channelNameField = channelType.GetField("ChannelName", BindingFlags.Public | BindingFlags.Static);
        var portTypeField = channelType.GetField("PortType", BindingFlags.Public | BindingFlags.Static);
        var maxMsgSizeField = channelType.GetField("MaxMessageSize", BindingFlags.Public | BindingFlags.Static);
        var messageProp = channelType.GetProperty("Message", BindingFlags.Public | BindingFlags.Instance);

        if (directionField is null || portNameField is null || channelNameField is null ||
            portTypeField is null || maxMsgSizeField is null || messageProp is null)
        {
            return null;
        }

        var direction = (string)directionField.GetRawConstantValue()!;
        var portName = (string)portNameField.GetRawConstantValue()!;
        var channelName = (string)channelNameField.GetRawConstantValue()!;
        var portType = (string)portTypeField.GetRawConstantValue()!;
        var maxMessageSize = (int)maxMsgSizeField.GetRawConstantValue()!;

        var channel = new ChannelNode
        {
            Direction = direction,
            PortName = portName,
            PortType = MsgAssemblyLoader.ParsePortType(portType),
            ChannelName = channelName,
            MaxMessageSize = maxMessageSize,
            ChannelType = channelType,
            MessageType = messageProp.PropertyType,
            MessageGetter = MsgAssemblyLoader.CreateGetter(messageProp),
            MessageSetter = MsgAssemblyLoader.CreateSetter(messageProp)
        };

        // Optional sampling field
        var refreshField = channelType.GetField("RefreshPeriodNs", BindingFlags.Public | BindingFlags.Static);
        if (refreshField is not null)
        {
            channel.RefreshPeriodNs = (long)refreshField.GetRawConstantValue()!;
        }

        // Optional queuing fields
        var maxNbField = channelType.GetField("MaxNbMessage", BindingFlags.Public | BindingFlags.Static);
        if (maxNbField is not null)
        {
            channel.MaxNbMessage = (int)maxNbField.GetRawConstantValue()!;
        }

        var disciplineField = channelType.GetField("QueuingDiscipline", BindingFlags.Public | BindingFlags.Static);
        if (disciplineField is not null)
        {
            channel.QueuingDiscipline = MsgAssemblyLoader.ParseQueuingDiscipline(
                (string)disciplineField.GetRawConstantValue()!);
        }
        else if (channel.PortType == PortType.Queuing)
        {
            channel.QueuingDiscipline = QueuingDiscipline.FIFO;
        }

        // Discover fields on the message type
        channel.Fields = BuildFieldNodes(messageProp.PropertyType, "", msg => msg);

        return channel;
    }

    private static List<FieldNode> BuildFieldNodes(Type messageType, string prefix, Func<object, object?> parentAccessor)
    {
        var fields = new List<FieldNode>();

        foreach (var prop in messageType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            if (prop.Name == "Message")
            {
                continue;
            }

            var displayName = string.IsNullOrEmpty(prefix) ? prop.Name : $"{prefix}.{prop.Name}";

            if (MsgAssemblyLoader.TryGetCollectionElementType(prop.PropertyType, out var elemType))
            {
                var isListType = !prop.PropertyType.IsArray;

                // Char array/list → treat as single string field (C string)
                if (elemType == typeof(char))
                {
                    var lengthFieldC = messageType.GetField($"{prop.Name}Length", BindingFlags.Public | BindingFlags.Static);
                    var charLen = lengthFieldC is not null ? (int)lengthFieldC.GetRawConstantValue()! : 0;

                    fields.Add(new FieldNode
                    {
                        DisplayName = displayName,
                        FieldType = typeof(string),
                        IsNested = false,
                        MaxLength = charLen,
                        GetParentObject = parentAccessor,
                        CompiledGetter = isListType
                            ? MsgAssemblyLoader.CreateCharListStringGetter(prop)
                            : MsgAssemblyLoader.CreateCharArrayStringGetter(prop),
                        CompiledSetter = isListType
                            ? MsgAssemblyLoader.CreateCharListStringSetter(prop, charLen)
                            : MsgAssemblyLoader.CreateCharArrayStringSetter(prop, charLen)
                    });
                    continue;
                }

                var lengthField = messageType.GetField($"{prop.Name}Length", BindingFlags.Public | BindingFlags.Static);
                var collectionLen = lengthField is not null ? (int)lengthField.GetRawConstantValue()! : 0;

                var collectionNode = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = prop.PropertyType,
                    IsNested = true,
                    IsArray = true,
                    ArrayLength = collectionLen,
                    NestedFields = new List<FieldNode>(),
                    GetParentObject = parentAccessor
                };
                fields.Add(collectionNode);

                var isPrimitiveElement = MsgAssemblyLoader.IsPrimitiveField(elemType);

                for (var i = 0; i < collectionLen; i++)
                {
                    var capturedIndex = i;
                    var capturedProp = prop;
                    var capturedParent = parentAccessor;

                    if (isPrimitiveElement)
                    {
                        var elemField = new FieldNode
                        {
                            DisplayName = $"{displayName}[{i}]",
        
                            FieldType = elemType,
                            IsArray = true,
                            ArrayIndex = capturedIndex,
                            GetParentObject = parentAccessor,
                            CompiledGetter = isListType
                                ? MsgAssemblyLoader.CreateListElementGetter(prop, capturedIndex)
                                : MsgAssemblyLoader.CreateArrayElementGetter(prop, capturedIndex),
                            CompiledSetter = isListType
                                ? MsgAssemblyLoader.CreateListElementSetter(prop, capturedIndex, elemType)
                                : MsgAssemblyLoader.CreateArrayElementSetter(prop, capturedIndex, elemType)
                        };
                        collectionNode.NestedFields.Add(elemField);
                        fields.Add(elemField);
                    }
                    else
                    {
                        Func<object, object?> elemAccessor = msg =>
                        {
                            var parent = capturedParent(msg);
                            if (parent is null) { return null; }
                            var collection = capturedProp.GetValue(parent);
                            if (collection is Array arr)
                            {
                                return arr.GetValue(capturedIndex);
                            }
                            if (collection is IList list && capturedIndex < list.Count)
                            {
                                return list[capturedIndex];
                            }
                            return null;
                        };

                        var elemDisplayName = $"{displayName}[{i}]";
                        var nestedFields = BuildFieldNodes(elemType, elemDisplayName, elemAccessor);

                        var elemNode = new FieldNode
                        {
                            DisplayName = elemDisplayName,
        
                            FieldType = elemType,
                            IsNested = true,
                            IsArray = true,
                            ArrayIndex = capturedIndex,
                            NestedFields = nestedFields,
                            GetParentObject = parentAccessor
                        };
                        collectionNode.NestedFields.Add(elemNode);
                        fields.Add(elemNode);
                        fields.AddRange(nestedFields);
                    }
                }
            }
            else if (MsgAssemblyLoader.IsPrimitiveField(prop.PropertyType))
            {
                var field = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = prop.PropertyType,
                    IsNested = false,
                    GetParentObject = parentAccessor,
                    CompiledGetter = MsgAssemblyLoader.CreateGetter(prop),
                    CompiledSetter = MsgAssemblyLoader.CreateSetter(prop)
                };

                // Look for Min/Max constants
                var minField = messageType.GetField($"{prop.Name}Min", BindingFlags.Public | BindingFlags.Static);
                if (minField is not null)
                {
                    field.Min = minField.GetRawConstantValue();
                }

                var maxField = messageType.GetField($"{prop.Name}Max", BindingFlags.Public | BindingFlags.Static);
                if (maxField is not null)
                {
                    field.Max = maxField.GetRawConstantValue();
                }

                var resField = messageType.GetField($"{prop.Name}Resolution", BindingFlags.Public | BindingFlags.Static);
                if (resField is not null)
                {
                    field.Resolution = resField.GetRawConstantValue();
                }

                // Look for MaxLength constant (for strings)
                var maxLenField = messageType.GetField($"{prop.Name}MaxLength", BindingFlags.Public | BindingFlags.Static);
                if (maxLenField is not null)
                {
                    field.MaxLength = (int)maxLenField.GetRawConstantValue()!;
                }

                fields.Add(field);
            }
            else
            {
                // Nested type — recurse
                var capturedProp = prop;
                var capturedParent = parentAccessor;
                Func<object, object?> nestedAccessor = msg =>
                {
                    var parent = capturedParent(msg);
                    return parent is null ? null : capturedProp.GetValue(parent);
                };

                var nestedFields = BuildFieldNodes(prop.PropertyType, displayName, nestedAccessor);

                var field = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = prop.PropertyType,
                    IsNested = true,
                    NestedFields = nestedFields,
                    GetParentObject = parentAccessor
                };

                fields.Add(field);
                fields.AddRange(nestedFields);
            }
        }

        return fields;
    }
}
