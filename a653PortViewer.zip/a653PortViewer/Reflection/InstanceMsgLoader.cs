using System.Collections;
using System.Reflection;

namespace A653PortViewer.Reflection;

/// <summary>
/// Loads assemblies where channel metadata is stored as instance fields and message field
/// constraints use the <c>{field_name}_MIN/_MAX/_RES</c> naming convention.
/// Message accessor on channel is the <c>chd</c> instance field instead of a <c>Message</c> property.
/// Direction is inferred from PortName (_O_ = source, _I_ = destination).
/// Array lengths are read from the actual collection instance, not from a static constant.
/// </summary>
public sealed class InstanceMsgLoader : IMsgLoader
{
    public List<PartitionNode> Load(Assembly assembly)
    {
        var partitions = new List<PartitionNode>();

        foreach (var (type, name, ns) in MsgAssemblyLoader.DiscoverPartitions(assembly))
        {
            var partition = new PartitionNode
            {
                Name = name,
                Namespace = ns,
                Type = type
            };

            foreach (var channelType in MsgAssemblyLoader.DiscoverChannelTypes(type))
            {
                var channel = BuildChannelNode(channelType);
                if (channel is not null)
                {
                    partition.Channels.Add(channel);
                }
            }

            partitions.Add(partition);
        }

        return partitions;
    }

    private static ChannelNode? BuildChannelNode(Type channelType)
    {
        // Create temp instance to read instance field values
        object? tempInstance;
        try
        {
            tempInstance = Activator.CreateInstance(channelType);
        }
        catch
        {
            return null;
        }

        if (tempInstance is null)
        {
            return null;
        }

        // Read required metadata from instance fields
        var portName = ReadInstanceField<string>(channelType, "PortName", tempInstance);
        var channelName = ReadInstanceField<string>(channelType, "ChannelName", tempInstance);
        var maxMessageSize = ReadInstanceField<int>(channelType, "MaxMessageSize", tempInstance);

        if (portName is null || channelName is null)
        {
            return null;
        }

        // Direction inferred from port name
        var direction = InferDirection(portName);

        // PortType — instance field, could be enum or string
        var portType = ReadPortType(channelType, tempInstance);

        // Message type from "chd" instance field
        var chdField = channelType.GetField("chd", BindingFlags.Public | BindingFlags.Instance);
        // Fall back to "Message" property if "chd" doesn't exist
        var messageProp = channelType.GetProperty("Message", BindingFlags.Public | BindingFlags.Instance);

        if (chdField is null && messageProp is null)
        {
            return null;
        }

        var messageType = chdField is not null ? chdField.FieldType : messageProp!.PropertyType;

        var channel = new ChannelNode
        {
            Direction = direction,
            PortName = portName,
            PortType = portType,
            ChannelName = channelName,
            MaxMessageSize = maxMessageSize,
            ChannelType = channelType,
            MessageType = messageType,
            MessageGetter = chdField is not null
                ? MsgAssemblyLoader.CreateGetter(chdField)
                : MsgAssemblyLoader.CreateGetter(messageProp!),
            MessageSetter = chdField is not null
                ? MsgAssemblyLoader.CreateSetter(chdField)
                : MsgAssemblyLoader.CreateSetter(messageProp!)
        };

        // Optional sampling field
        var refreshPeriod = ReadInstanceField<long>(channelType, "RefreshPeriodNs", tempInstance);
        if (refreshPeriod != 0)
        {
            channel.RefreshPeriodNs = refreshPeriod;
        }

        // Optional queuing fields
        var maxNbMessage = ReadInstanceField<int>(channelType, "MaxNbMessage", tempInstance);
        if (maxNbMessage != 0)
        {
            channel.MaxNbMessage = maxNbMessage;
        }

        // Default queuing discipline to FIFO for queuing ports
        if (channel.PortType == PortType.Queuing)
        {
            channel.QueuingDiscipline = QueuingDiscipline.FIFO;
        }

        // Discover fields on the message type
        channel.Fields = BuildFieldNodes(messageType, "", msg => msg);

        return channel;
    }

    private static List<FieldNode> BuildFieldNodes(Type messageType, string prefix, Func<object, object?> parentAccessor)
    {
        var fields = new List<FieldNode>();

        // Create temp instance for reading array/list lengths
        object? tempMsgInstance = null;
        try
        {
            tempMsgInstance = Activator.CreateInstance(messageType);
        }
        catch
        {
            // Type may not have parameterless constructor
        }

        // Iterate instance fields (not properties) — skip static fields (MIN/MAX/RES etc.)
        foreach (var fi in messageType.GetFields(BindingFlags.Public | BindingFlags.Instance))
        {
            if (fi.Name == "chd")
            {
                continue;
            }

            var displayName = string.IsNullOrEmpty(prefix) ? fi.Name : $"{prefix}.{fi.Name}";

            if (MsgAssemblyLoader.TryGetCollectionElementType(fi.FieldType, out var elemType))
            {
                var isListType = !fi.FieldType.IsArray;

                // Char array/list → treat as single string field (C string)
                if (elemType == typeof(char))
                {
                    var charLen = 0;
                    if (tempMsgInstance is not null)
                    {
                        var collection = fi.GetValue(tempMsgInstance);
                        if (collection is Array arr) { charLen = arr.Length; }
                        else if (collection is IList list) { charLen = list.Count; }
                    }

                    fields.Add(new FieldNode
                    {
                        DisplayName = displayName,
                        FieldType = typeof(string),
                        IsNested = false,
                        MaxLength = charLen,
                        GetParentObject = parentAccessor,
                        CompiledGetter = isListType
                            ? MsgAssemblyLoader.CreateCharListStringGetter(fi)
                            : MsgAssemblyLoader.CreateCharArrayStringGetter(fi),
                        CompiledSetter = isListType
                            ? MsgAssemblyLoader.CreateCharListStringSetter(fi, charLen)
                            : MsgAssemblyLoader.CreateCharArrayStringSetter(fi, charLen)
                    });
                    continue;
                }

                // Read collection length from the temp instance
                var collectionLen = 0;
                if (tempMsgInstance is not null)
                {
                    var collection = fi.GetValue(tempMsgInstance);
                    if (collection is Array arr)
                    {
                        collectionLen = arr.Length;
                    }
                    else if (collection is IList list)
                    {
                        collectionLen = list.Count;
                    }
                }

                var collectionNode = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = fi.FieldType,
                    IsNested = true,
                    IsArray = true,
                    ArrayLength = collectionLen,
                    NestedFields = new List<FieldNode>(),
                    GetParentObject = parentAccessor
                };
                fields.Add(collectionNode);

                var isPrimitiveElement = MsgAssemblyLoader.IsPrimitiveField(elemType);

                for (var i = 0; i < collectionLen; i++)
                {
                    var capturedIndex = i;
                    var capturedField = fi;
                    var capturedParent = parentAccessor;

                    if (isPrimitiveElement)
                    {
                        var elemField = new FieldNode
                        {
                            DisplayName = $"{displayName}[{i}]",
        
                            FieldType = elemType,
                            IsArray = true,
                            ArrayIndex = capturedIndex,
                            GetParentObject = parentAccessor,
                            CompiledGetter = isListType
                                ? MsgAssemblyLoader.CreateListElementGetter(fi, capturedIndex)
                                : MsgAssemblyLoader.CreateArrayElementGetter(fi, capturedIndex),
                            CompiledSetter = isListType
                                ? MsgAssemblyLoader.CreateListElementSetter(fi, capturedIndex, elemType)
                                : MsgAssemblyLoader.CreateArrayElementSetter(fi, capturedIndex, elemType)
                        };
                        collectionNode.NestedFields.Add(elemField);
                        fields.Add(elemField);
                    }
                    else
                    {
                        Func<object, object?> elemAccessor = msg =>
                        {
                            var parent = capturedParent(msg);
                            if (parent is null) { return null; }
                            var collection = capturedField.GetValue(parent);
                            if (collection is Array arr)
                            {
                                return arr.GetValue(capturedIndex);
                            }
                            if (collection is IList list && capturedIndex < list.Count)
                            {
                                return list[capturedIndex];
                            }
                            return null;
                        };

                        var elemDisplayName = $"{displayName}[{i}]";
                        var nestedFields = BuildFieldNodes(elemType, elemDisplayName, elemAccessor);

                        var elemNode = new FieldNode
                        {
                            DisplayName = elemDisplayName,
        
                            FieldType = elemType,
                            IsNested = true,
                            IsArray = true,
                            ArrayIndex = capturedIndex,
                            NestedFields = nestedFields,
                            GetParentObject = parentAccessor
                        };
                        collectionNode.NestedFields.Add(elemNode);
                        fields.Add(elemNode);
                        fields.AddRange(nestedFields);
                    }
                }
            }
            else if (MsgAssemblyLoader.IsPrimitiveField(fi.FieldType))
            {
                var field = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = fi.FieldType,
                    IsNested = false,
                    GetParentObject = parentAccessor,
                    CompiledGetter = MsgAssemblyLoader.CreateGetter(fi),
                    CompiledSetter = MsgAssemblyLoader.CreateSetter(fi)
                };

                // Look for {fi.Name}_MIN/_MAX/_RES as public static fields
                var minField = messageType.GetField($"{fi.Name}_MIN", BindingFlags.Public | BindingFlags.Static);
                if (minField is not null)
                {
                    field.Min = minField.GetValue(null);
                }

                var maxField = messageType.GetField($"{fi.Name}_MAX", BindingFlags.Public | BindingFlags.Static);
                if (maxField is not null)
                {
                    field.Max = maxField.GetValue(null);
                }

                var resField = messageType.GetField($"{fi.Name}_RES", BindingFlags.Public | BindingFlags.Static);
                if (resField is not null)
                {
                    field.Resolution = resField.GetValue(null);
                }

                // Look for MaxLength for strings
                if (fi.FieldType == typeof(string))
                {
                    var maxLenField = messageType.GetField($"{fi.Name}_MAXLEN", BindingFlags.Public | BindingFlags.Static);
                    if (maxLenField is not null)
                    {
                        var raw = maxLenField.GetValue(null);
                        if (raw is int maxLen)
                        {
                            field.MaxLength = maxLen;
                        }
                    }
                }

                fields.Add(field);
            }
            else
            {
                // Nested type — recurse
                var capturedField = fi;
                var capturedParent = parentAccessor;
                Func<object, object?> nestedAccessor = msg =>
                {
                    var parent = capturedParent(msg);
                    return parent is null ? null : capturedField.GetValue(parent);
                };

                var nestedFields = BuildFieldNodes(fi.FieldType, displayName, nestedAccessor);

                var field = new FieldNode
                {
                    DisplayName = displayName,

                    FieldType = fi.FieldType,
                    IsNested = true,
                    NestedFields = nestedFields,
                    GetParentObject = parentAccessor
                };

                fields.Add(field);
                fields.AddRange(nestedFields);
            }
        }

        return fields;
    }

    /// <summary>
    /// Infers direction from port name. First _O_ means source, first _I_ means destination.
    /// </summary>
    private static string InferDirection(string portName)
    {
        var oIdx = portName.IndexOf("_O_", StringComparison.Ordinal);
        var iIdx = portName.IndexOf("_I_", StringComparison.Ordinal);

        if (oIdx >= 0 && (iIdx < 0 || oIdx < iIdx))
        {
            return "source";
        }

        if (iIdx >= 0)
        {
            return "destination";
        }

        return "source";
    }

    /// <summary>
    /// Reads the PortType from an instance field. Handles both string and enum field types.
    /// </summary>
    private static PortType ReadPortType(Type channelType, object tempInstance)
    {
        var field = channelType.GetField("PortType", BindingFlags.Public | BindingFlags.Instance);
        if (field is null)
        {
            return PortType.None;
        }

        var value = field.GetValue(tempInstance);
        if (value is null)
        {
            return PortType.None;
        }

        // If the field is already our PortType enum or a matching enum
        if (value is PortType pt)
        {
            return pt;
        }

        // If it's a string
        if (value is string str)
        {
            return MsgAssemblyLoader.ParsePortType(str);
        }

        // If it's some other enum, convert via ToString
        if (value.GetType().IsEnum)
        {
            return MsgAssemblyLoader.ParsePortType(value.ToString());
        }

        return PortType.None;
    }

    /// <summary>
    /// Reads a typed value from an instance field, returning default if not found.
    /// </summary>
    private static T ReadInstanceField<T>(Type type, string fieldName, object instance)
    {
        var field = type.GetField(fieldName, BindingFlags.Public | BindingFlags.Instance);
        if (field is not null)
        {
            var raw = field.GetValue(instance);
            if (raw is T typed)
            {
                return typed;
            }
        }

        return default!;
    }
}
