using System.Reflection;

namespace A653PortViewer.Reflection;

/// <summary>
/// Interface for loading ARINC 653 Msg assemblies via reflection.
/// Implementations handle different code generation conventions (const vs instance fields).
/// </summary>
public interface IMsgLoader
{
    /// <summary>
    /// Discovers partitions, channels, and field metadata from an assembly.
    /// </summary>
    List<PartitionNode> Load(Assembly assembly);
}
