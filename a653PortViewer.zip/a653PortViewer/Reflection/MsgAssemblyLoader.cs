using System.Linq.Expressions;
using System.Reflection;

namespace A653PortViewer.Reflection;

/// <summary>
/// Port type classification for A653 channels.
/// </summary>
public enum PortType
{
    None,
    Sampling,
    Queuing
}

/// <summary>
/// Queuing discipline for queuing ports.
/// </summary>
public enum QueuingDiscipline
{
    None,
    FIFO,
    Priority
}

/// <summary>
/// Data model representing a discovered partition from the Msg assembly.
/// </summary>
public sealed class PartitionNode
{
    public string Name { get; set; } = "";
    public string Namespace { get; set; } = "";
    public Type Type { get; set; } = null!;
    public List<ChannelNode> Channels { get; set; } = new List<ChannelNode>();
}

/// <summary>
/// Data model representing a discovered channel (port) within a partition.
/// </summary>
public sealed class ChannelNode
{
    public string Direction { get; set; } = "";
    public string PortName { get; set; } = "";
    public PortType PortType { get; set; }
    public string ChannelName { get; set; } = "";
    public int MaxMessageSize { get; set; }
    public long? RefreshPeriodNs { get; set; }
    public int? MaxNbMessage { get; set; }
    public QueuingDiscipline QueuingDiscipline { get; set; }

    public Type ChannelType { get; set; } = null!;
    public Type MessageType { get; set; } = null!;
    public List<FieldNode> Fields { get; set; } = new List<FieldNode>();

    /// <summary>
    /// Compiled delegate to get the Message object from an instance. Set by loaders.
    /// </summary>
    public Func<object, object?>? MessageGetter { get; set; }

    /// <summary>
    /// Compiled delegate to set the Message object on an instance. Set by loaders.
    /// </summary>
    public Action<object, object?>? MessageSetter { get; set; }

    // Runtime state
    public object? Instance { get; set; }
    public object? Message { get; set; }
    public DateTime? LastUpdateTime { get; set; }
    public bool IsSubscribed { get; set; }

    /// <summary>
    /// Lock object for thread-safe access to Instance, Message, and field values.
    /// External code and UI thread must both lock on this before reading/writing Message properties.
    /// </summary>
    public readonly object Lock = new();

    /// <summary>
    /// Message history for all port types. Limited to MaxHistoryEntries.
    /// </summary>
    public List<MessageHistoryEntry> MessageHistory { get; set; } = new List<MessageHistoryEntry>();
    public int MessageHistoryGeneration { get; set; }

    /// <summary>
    /// Maximum number of history entries to keep. Default 10. Set to 0 for unlimited. Set to -1 to disable.
    /// </summary>
    public int MaxHistoryEntries { get; set; } = -1;

    /// <summary>
    /// Latest snapshot of all leaf field values. Produced by writers (MsgComm thread or UI edit).
    /// Read by UI refresh timer without locking — reference swap is atomic on .NET.
    /// </summary>
    public Dictionary<string, string>? LastSnapshot { get; set; }

    private long _snapshotGeneration;

    /// <summary>
    /// Incremented each time LastSnapshot is updated. Use Interlocked.Read for cross-thread reads.
    /// </summary>
    public long SnapshotGeneration => Interlocked.Read(ref _snapshotGeneration);

    /// <summary>
    /// Builds a snapshot of all leaf field values and stores it in LastSnapshot.
    /// Call after writing field values. Acquires Lock internally.
    /// </summary>
    public void BuildSnapshot()
    {
        if (Message is null)
        {
            return;
        }

        var snap = SnapshotFields();
        LastSnapshot = snap;
        Interlocked.Increment(ref _snapshotGeneration);
    }

    /// <summary>
    /// Iterates all leaf fields under Lock and returns a dictionary of display name to string value.
    /// </summary>
    private Dictionary<string, string> SnapshotFields()
    {
        var snap = new Dictionary<string, string>(Fields.Count, StringComparer.Ordinal);
        lock (Lock)
        {
            foreach (var field in Fields)
            {
                if (field.IsNested || field.CompiledGetter is null || field.GetParentObject is null)
                {
                    continue;
                }

                var parent = field.GetParentObject(Message);
                if (parent is not null)
                {
                    var value = field.CompiledGetter(parent);
                    snap[field.DisplayName] = value?.ToString() ?? "";
                }
            }
        }

        return snap;
    }

    /// <summary>
    /// Snapshots all leaf field values, updates LastSnapshot, and optionally records a history entry.
    /// Call after writing fields. Always updates snapshot even if history is disabled.
    /// </summary>
    public void RecordHistory(string direction)
    {
        if (Message is null)
        {
            return;
        }

        var snap = SnapshotFields();
        LastSnapshot = snap;
        Interlocked.Increment(ref _snapshotGeneration);

        if (MaxHistoryEntries < 0)
        {
            return;
        }

        var entry = new MessageHistoryEntry
        {
            Timestamp = DateTime.Now,
            Direction = direction,
            Fields = snap
        };

        MessageHistory.Add(entry);
        MessageHistoryGeneration++;

        // Enforce limit
        if (MaxHistoryEntries > 0 && MessageHistory.Count > MaxHistoryEntries)
        {
            MessageHistory.RemoveAt(0);
        }
    }

    /// <summary>
    /// Gets the Message object from the channel instance via compiled delegate.
    /// </summary>
    public object? GetMessageFromInstance()
    {
        if (Instance is null || MessageGetter is null)
        {
            return null;
        }

        return MessageGetter(Instance);
    }

    /// <summary>
    /// Sets the Message object on the channel instance via compiled delegate.
    /// </summary>
    public void SetMessageOnInstance(object? value)
    {
        if (Instance is null || MessageSetter is null)
        {
            return;
        }

        MessageSetter(Instance, value);
    }
}

/// <summary>
/// A snapshot of a queuing port message at a point in time.
/// </summary>
public sealed class MessageHistoryEntry
{
    public DateTime Timestamp { get; set; }
    public string Direction { get; set; } = "";
    public Dictionary<string, string> Fields { get; set; } = new Dictionary<string, string>();
}

/// <summary>
/// Data model representing a field (property or instance field) within a message type, including nested fields.
/// </summary>
public sealed class FieldNode
{
    public string DisplayName { get; set; } = "";
    public Type FieldType { get; set; } = null!;
    public bool IsNested { get; set; }
    public bool IsArray { get; set; }
    public int ArrayIndex { get; set; } = -1;
    public object? Min { get; set; }
    public object? Max { get; set; }
    public object? Resolution { get; set; }
    public int? MaxLength { get; set; }
    public int? ArrayLength { get; set; }
    public List<FieldNode>? NestedFields { get; set; }

    /// <summary>
    /// Given the root Message object, returns the parent object that owns this property/field.
    /// For top-level fields, returns the Message itself.
    /// For nested fields (e.g., Position.Latitude), returns the nested object (Position).
    /// </summary>
    public Func<object, object?>? GetParentObject { get; set; }

    /// <summary>
    /// Compiled getter delegate — ~100x faster than reflection.
    /// Always set for leaf (non-nested) nodes by both loaders.
    /// </summary>
    public Func<object, object?>? CompiledGetter { get; set; }

    /// <summary>
    /// Compiled setter delegate — ~100x faster than reflection.
    /// Always set for leaf (non-nested) nodes by both loaders.
    /// </summary>
    public Action<object, object?>? CompiledSetter { get; set; }
}

/// <summary>
/// Facade for loading ARINC 653 Msg assemblies. Tries ConstMsgLoader first,
/// falls back to InstanceMsgLoader if no channels are found.
/// </summary>
public static class MsgAssemblyLoader
{
    internal static readonly HashSet<Type> PrimitiveFieldTypes = new HashSet<Type>
    {
        typeof(float),
        typeof(double),
        typeof(int),
        typeof(uint),
        typeof(long),
        typeof(ulong),
        typeof(short),
        typeof(ushort),
        typeof(byte),
        typeof(sbyte),
        typeof(bool),
        typeof(char),
        typeof(string)
    };

    /// <summary>
    /// Loads the specified DLL and discovers all partition, channel, and field metadata.
    /// Does not instantiate any channel objects.
    /// </summary>
    public static List<PartitionNode> LoadAssembly(string dllPath)
    {
        if (string.IsNullOrWhiteSpace(dllPath))
            throw new ArgumentException("Value cannot be null or whitespace.", nameof(dllPath));
        return LoadAssembly(Assembly.LoadFrom(dllPath));
    }

    /// <summary>
    /// Loads an assembly by name (e.g., "MsgAssembly") from the current AppDomain's
    /// loaded assemblies or by probing the runtime. The assembly must already be
    /// loaded or resolvable via Assembly.Load().
    /// </summary>
    public static List<PartitionNode> LoadAssemblyByName(string assemblyName)
    {
        if (string.IsNullOrWhiteSpace(assemblyName))
            throw new ArgumentException("Value cannot be null or whitespace.", nameof(assemblyName));
        return LoadAssembly(Assembly.Load(assemblyName));
    }

    /// <summary>
    /// Discovers partitions, channels, and field metadata from an already-loaded assembly.
    /// Tries const-field loader first; falls back to instance-field loader if no channels found.
    /// </summary>
    public static List<PartitionNode> LoadAssembly(Assembly assembly)
    {
        ArgumentNullException.ThrowIfNull(assembly);

        var constLoader = new ConstMsgLoader();
        var result = constLoader.Load(assembly);
        if (result.Any(p => p.Channels.Count > 0))
        {
            return result;
        }

        var instanceLoader = new InstanceMsgLoader();
        return instanceLoader.Load(assembly);
    }

    // --- Shared helpers used by both loaders ---

    internal static bool IsPrimitiveField(Type type)
    {
        return PrimitiveFieldTypes.Contains(type);
    }

    /// <summary>
    /// Returns the element type for T[] arrays and List&lt;T&gt; collections.
    /// Returns false for non-collection types.
    /// </summary>
    internal static bool TryGetCollectionElementType(Type type, out Type elementType)
    {
        // T[] arrays
        if (type.IsArray)
        {
            elementType = type.GetElementType()!;
            return true;
        }

        // List<T>
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(List<>))
        {
            elementType = type.GetGenericArguments()[0];
            return true;
        }

        elementType = null!;
        return false;
    }

    /// <summary>
    /// Parses a port type string into the PortType enum.
    /// </summary>
    internal static PortType ParsePortType(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return PortType.None;
        }

        if (value.Equals("sampling", StringComparison.OrdinalIgnoreCase))
        {
            return PortType.Sampling;
        }

        if (value.Equals("queuing", StringComparison.OrdinalIgnoreCase))
        {
            return PortType.Queuing;
        }

        // Try parsing as enum name (for assemblies that use an enum type)
        if (Enum.TryParse<PortType>(value, ignoreCase: true, out var parsed))
        {
            return parsed;
        }

        return PortType.None;
    }

    /// <summary>
    /// Parses a queuing discipline string into the QueuingDiscipline enum.
    /// </summary>
    internal static QueuingDiscipline ParseQueuingDiscipline(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return QueuingDiscipline.None;
        }

        if (value.Equals("FIFO", StringComparison.OrdinalIgnoreCase))
        {
            return QueuingDiscipline.FIFO;
        }

        if (value.Equals("Priority", StringComparison.OrdinalIgnoreCase))
        {
            return QueuingDiscipline.Priority;
        }

        if (Enum.TryParse<QueuingDiscipline>(value, ignoreCase: true, out var parsed))
        {
            return parsed;
        }

        return QueuingDiscipline.None;
    }

    /// <summary>
    /// Discovers partition types (static classes ending with "Partition") from an assembly.
    /// Shared by both loaders.
    /// </summary>
    internal static List<(Type PartitionType, string Name, string Namespace)> DiscoverPartitions(Assembly assembly)
    {
        var result = new List<(Type, string, string)>();

        foreach (var type in assembly.GetExportedTypes())
        {
            if (!type.IsAbstract || !type.IsSealed)
            {
                continue;
            }

            if (!type.Name.EndsWith("Partition", StringComparison.Ordinal))
            {
                continue;
            }

            result.Add((type, type.Name.Replace("Partition", ""), type.Namespace ?? "Global"));
        }

        return result;
    }

    /// <summary>
    /// Discovers channel types (sealed nested classes ending with "Channel") from a partition type.
    /// Shared by both loaders.
    /// </summary>
    internal static List<Type> DiscoverChannelTypes(Type partitionType)
    {
        var result = new List<Type>();

        foreach (var nestedType in partitionType.GetNestedTypes(BindingFlags.Public))
        {
            if (nestedType.IsSealed && nestedType.Name.EndsWith("Channel", StringComparison.Ordinal))
            {
                result.Add(nestedType);
            }
        }

        return result;
    }

    // --- Char array/list ↔ string helpers (C string convention) ---

    internal static Func<object, object?> CreateCharArrayStringGetter(PropertyInfo prop)
    {
        var compiledGetter = CreateGetter(prop);
        return obj =>
        {
            var arr = compiledGetter(obj) as char[];
            return arr is not null ? new string(arr).TrimEnd('\0') : "";
        };
    }

    internal static Func<object, object?> CreateCharArrayStringGetter(FieldInfo field)
    {
        var compiledGetter = CreateGetter(field);
        return obj =>
        {
            var arr = compiledGetter(obj) as char[];
            return arr is not null ? new string(arr).TrimEnd('\0') : "";
        };
    }

    internal static Action<object, object?> CreateCharArrayStringSetter(PropertyInfo prop, int arrayLength)
    {
        var compiledSetter = CreateSetter(prop);
        return (obj, val) =>
        {
            var text = val as string ?? "";
            var chars = new char[arrayLength];
            var copyLen = Math.Min(text.Length, arrayLength);
            text.CopyTo(0, chars, 0, copyLen);
            compiledSetter(obj, chars);
        };
    }

    internal static Action<object, object?> CreateCharArrayStringSetter(FieldInfo field, int arrayLength)
    {
        var compiledSetter = CreateSetter(field);
        return (obj, val) =>
        {
            var text = val as string ?? "";
            var chars = new char[arrayLength];
            var copyLen = Math.Min(text.Length, arrayLength);
            text.CopyTo(0, chars, 0, copyLen);
            compiledSetter(obj, chars);
        };
    }

    internal static Func<object, object?> CreateCharListStringGetter(PropertyInfo prop)
    {
        var compiledGetter = CreateGetter(prop);
        return obj =>
        {
            var list = compiledGetter(obj) as List<char>;
            return list is not null ? new string(list.ToArray()).TrimEnd('\0') : "";
        };
    }

    internal static Func<object, object?> CreateCharListStringGetter(FieldInfo field)
    {
        var compiledGetter = CreateGetter(field);
        return obj =>
        {
            var list = compiledGetter(obj) as List<char>;
            return list is not null ? new string(list.ToArray()).TrimEnd('\0') : "";
        };
    }

    internal static Action<object, object?> CreateCharListStringSetter(PropertyInfo prop, int listLength)
    {
        var compiledSetter = CreateSetter(prop);
        return (obj, val) =>
        {
            var text = val as string ?? "";
            var chars = new List<char>(listLength);
            chars.AddRange(text.Length <= listLength ? text.ToCharArray() : text.Substring(0, listLength).ToCharArray());
            while (chars.Count < listLength) { chars.Add('\0'); }
            compiledSetter(obj, chars);
        };
    }

    internal static Action<object, object?> CreateCharListStringSetter(FieldInfo field, int listLength)
    {
        var compiledSetter = CreateSetter(field);
        return (obj, val) =>
        {
            var text = val as string ?? "";
            var chars = new List<char>(listLength);
            chars.AddRange(text.Length <= listLength ? text.ToCharArray() : text.Substring(0, listLength).ToCharArray());
            while (chars.Count < listLength) { chars.Add('\0'); }
            compiledSetter(obj, chars);
        };
    }

    // --- Compiled delegate creators (overloaded for PropertyInfo and FieldInfo) ---

    internal static Func<object, object?> CreateGetter(PropertyInfo prop)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, prop.DeclaringType!);
        var access = Expression.Property(cast, prop);
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Func<object, object?> CreateGetter(FieldInfo field)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, field.DeclaringType!);
        var access = Expression.Field(cast, field);
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Action<object, object?> CreateSetter(PropertyInfo prop)
    {
        var obj = Expression.Parameter(typeof(object), "obj");
        var val = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(obj, prop.DeclaringType!);
        var convert = Expression.Convert(val, prop.PropertyType);
        var assign = Expression.Assign(Expression.Property(cast, prop), convert);
        return Expression.Lambda<Action<object, object?>>(assign, obj, val).Compile();
    }

    internal static Action<object, object?> CreateSetter(FieldInfo field)
    {
        var obj = Expression.Parameter(typeof(object), "obj");
        var val = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(obj, field.DeclaringType!);
        var convert = Expression.Convert(val, field.FieldType);
        var assign = Expression.Assign(Expression.Field(cast, field), convert);
        return Expression.Lambda<Action<object, object?>>(assign, obj, val).Compile();
    }

    internal static Func<object, object?> CreateArrayElementGetter(PropertyInfo arrayProp, int index)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, arrayProp.DeclaringType!);
        var array = Expression.Property(cast, arrayProp);
        var access = Expression.ArrayIndex(array, Expression.Constant(index));
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Func<object, object?> CreateArrayElementGetter(FieldInfo arrayField, int index)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, arrayField.DeclaringType!);
        var array = Expression.Field(cast, arrayField);
        var access = Expression.ArrayIndex(array, Expression.Constant(index));
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Action<object, object?> CreateArrayElementSetter(PropertyInfo arrayProp, int index, Type elemType)
    {
        var objParam = Expression.Parameter(typeof(object), "obj");
        var valParam = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(objParam, arrayProp.DeclaringType!);
        var array = Expression.Property(cast, arrayProp);
        var access = Expression.ArrayAccess(array, Expression.Constant(index));
        var assign = Expression.Assign(access, Expression.Convert(valParam, elemType));
        return Expression.Lambda<Action<object, object?>>(assign, objParam, valParam).Compile();
    }

    internal static Action<object, object?> CreateArrayElementSetter(FieldInfo arrayField, int index, Type elemType)
    {
        var objParam = Expression.Parameter(typeof(object), "obj");
        var valParam = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(objParam, arrayField.DeclaringType!);
        var array = Expression.Field(cast, arrayField);
        var access = Expression.ArrayAccess(array, Expression.Constant(index));
        var assign = Expression.Assign(access, Expression.Convert(valParam, elemType));
        return Expression.Lambda<Action<object, object?>>(assign, objParam, valParam).Compile();
    }

    internal static Func<object, object?> CreateListElementGetter(PropertyInfo listProp, int index)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, listProp.DeclaringType!);
        var list = Expression.Property(cast, listProp);
        var itemProp = listProp.PropertyType.GetProperty("Item")!;
        var access = Expression.MakeIndex(list, itemProp, new[] { Expression.Constant(index) });
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Func<object, object?> CreateListElementGetter(FieldInfo listField, int index)
    {
        var param = Expression.Parameter(typeof(object), "obj");
        var cast = Expression.Convert(param, listField.DeclaringType!);
        var list = Expression.Field(cast, listField);
        var itemProp = listField.FieldType.GetProperty("Item")!;
        var access = Expression.MakeIndex(list, itemProp, new[] { Expression.Constant(index) });
        var box = Expression.Convert(access, typeof(object));
        return Expression.Lambda<Func<object, object?>>(box, param).Compile();
    }

    internal static Action<object, object?> CreateListElementSetter(PropertyInfo listProp, int index, Type elemType)
    {
        var objParam = Expression.Parameter(typeof(object), "obj");
        var valParam = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(objParam, listProp.DeclaringType!);
        var list = Expression.Property(cast, listProp);
        var itemProp = listProp.PropertyType.GetProperty("Item")!;
        var access = Expression.MakeIndex(list, itemProp, new[] { Expression.Constant(index) });
        var assign = Expression.Assign(access, Expression.Convert(valParam, elemType));
        return Expression.Lambda<Action<object, object?>>(assign, objParam, valParam).Compile();
    }

    internal static Action<object, object?> CreateListElementSetter(FieldInfo listField, int index, Type elemType)
    {
        var objParam = Expression.Parameter(typeof(object), "obj");
        var valParam = Expression.Parameter(typeof(object), "val");
        var cast = Expression.Convert(objParam, listField.DeclaringType!);
        var list = Expression.Field(cast, listField);
        var itemProp = listField.FieldType.GetProperty("Item")!;
        var access = Expression.MakeIndex(list, itemProp, new[] { Expression.Constant(index) });
        var assign = Expression.Assign(access, Expression.Convert(valParam, elemType));
        return Expression.Lambda<Action<object, object?>>(assign, objParam, valParam).Compile();
    }
}
