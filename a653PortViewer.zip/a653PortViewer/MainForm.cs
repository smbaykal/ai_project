using System.Text.Json;
using A653PortViewer.Reflection;

namespace A653PortViewer;

/// <summary>
/// Main application form providing a hierarchical port viewer for ARINC 653 Msg assemblies.
/// Shows a TreeView with partitions and channels. Double-clicking a subscribed channel
/// opens a separate detail window for that port.
/// </summary>
public partial class MainForm : Form
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        AllowTrailingCommas = true,
        ReadCommentHandling = JsonCommentHandling.Skip
    };

    private readonly Dictionary<string, ChannelNode> _channelsByPortName = new(StringComparer.Ordinal);
    private readonly Dictionary<string, ChannelDetailForm> _openDetailForms = new(StringComparer.Ordinal);
    private List<PartitionNode> _partitions = new List<PartitionNode>();
    private Action<object>? _sendCallback;
    private bool _suppressCheckEvents;
    private Font? _boldFont;

    /// <summary>
    /// Raised when a channel is subscribed or unsubscribed.
    /// Thread-safe: handlers may be invoked from the UI thread.
    /// </summary>
    public event Action<ChannelNode, bool>? ChannelSubscriptionChanged;

    // Cached subscription lists — invalidated on check/uncheck
    private IReadOnlyList<ChannelNode>? _subscribedCache;
    private IReadOnlyList<ChannelNode>? _subscribedSourceCache;
    private IReadOnlyList<ChannelNode>? _subscribedDestCache;

    /// <summary>
    /// Gets or sets the timer refresh interval in milliseconds.
    /// </summary>
    public int RefreshIntervalMs
    {
        get => _refreshTimer.Interval;
        set
        {
            _refreshTimer.Interval = value;
            // Update interval on any open detail forms
            foreach (var form in _openDetailForms.Values)
            {
                // Detail forms manage their own timers, but we keep this for API consistency
            }
        }
    }

    public MainForm()
    {
        InitializeComponent();
        Load += MainForm_Load;
        FormClosing += MainForm_FormClosing;
    }

    /// <summary>
    /// Loads a Msg assembly from the specified DLL file path.
    /// </summary>
    public void LoadDll(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Value cannot be null or whitespace.", nameof(path));

        List<PartitionNode> partitions;
        try
        {
            partitions = MsgAssemblyLoader.LoadAssembly(path);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Failed to load assembly:\n{ex.Message}", "Load Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        LoadPartitions(partitions);
        Text = $"A653 Port Viewer \u2014 {Path.GetFileName(path)}";
        SetActionStatus($"Loaded {Path.GetFileName(path)}");
    }

    /// <summary>
    /// Loads a Msg assembly by name (e.g., "MsgAssembly").
    /// </summary>
    public void LoadByName(string assemblyName)
    {
        if (string.IsNullOrWhiteSpace(assemblyName))
            throw new ArgumentException("Value cannot be null or whitespace.", nameof(assemblyName));

        List<PartitionNode> partitions;
        try
        {
            partitions = MsgAssemblyLoader.LoadAssemblyByName(assemblyName);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Failed to load assembly '{assemblyName}':\n{ex.Message}", "Load Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        LoadPartitions(partitions);
        Text = $"A653 Port Viewer \u2014 {assemblyName}";
        SetActionStatus($"Loaded {assemblyName}");
    }

    /// <summary>
    /// Loads pre-discovered partitions into the tree view. Call this from external code
    /// that has already loaded an assembly via MsgAssemblyLoader.LoadAssembly().
    /// </summary>
    public void LoadPartitions(List<PartitionNode> partitions)
    {
        _refreshTimer.Stop();
        CloseAllDetailForms();
        _channelsByPortName.Clear();
        _treeView.Nodes.Clear();
        InvalidateSubscriptionCaches();

        _partitions = partitions;
        PopulateTreeView();
        _refreshTimer.Start();

        // Restore saved subscriptions and channel data if state file exists
        RestoreSubscriptionsFromState();

        UpdateSubscriptionStatus();
    }

    /// <summary>
    /// Returns the ChannelNode for the given port name, or null if not found.
    /// Thread-safe. Use channel.Lock before accessing Message properties.
    /// </summary>
    public ChannelNode? GetChannel(string portName)
    {
        return _channelsByPortName.TryGetValue(portName, out var node) ? node : null;
    }

    /// <summary>
    /// Returns the channel instance for the given port name, or null if not subscribed.
    /// Thread-safe snapshot — the instance reference itself is safe to hold.
    /// </summary>
    public object? GetChannelInstance(string portName)
    {
        return _channelsByPortName.TryGetValue(portName, out var node) ? node.Instance : null;
    }

    /// <summary>
    /// Returns the Message object for the given port name, or null if not subscribed.
    /// Thread-safe snapshot — lock on channel.Lock before reading/writing Message properties.
    /// </summary>
    public object? GetChannelMessage(string portName)
    {
        return _channelsByPortName.TryGetValue(portName, out var node) ? node.Message : null;
    }

    /// <summary>
    /// Returns whether the given port name is currently subscribed (checked).
    /// </summary>
    public bool IsChannelSubscribed(string portName)
    {
        return _channelsByPortName.TryGetValue(portName, out var node) && node.IsSubscribed;
    }

    /// <summary>
    /// Returns a snapshot of all currently subscribed channels. Thread-safe.
    /// </summary>
    public IReadOnlyList<ChannelNode> GetSubscribedChannels()
    {
        return _subscribedCache ??= _channelsByPortName.Values
            .Where(c => c.IsSubscribed).ToList().AsReadOnly();
    }

    /// <summary>
    /// Returns a cached snapshot of all subscribed source channels. Thread-safe.
    /// </summary>
    public IReadOnlyList<ChannelNode> GetSubscribedSourceChannels()
    {
        return _subscribedSourceCache ??= _channelsByPortName.Values
            .Where(c => c.IsSubscribed && c.Direction is "source")
            .ToList().AsReadOnly();
    }

    /// <summary>
    /// Returns a cached snapshot of all subscribed destination channels. Thread-safe.
    /// </summary>
    public IReadOnlyList<ChannelNode> GetSubscribedDestinationChannels()
    {
        return _subscribedDestCache ??= _channelsByPortName.Values
            .Where(c => c.IsSubscribed && c.Direction is "destination")
            .ToList().AsReadOnly();
    }

    /// <summary>
    /// Called by the msgComm thread after writing new data into a destination channel's Message.
    /// Stamps LastUpdateTime so the UI shows when data last arrived.
    /// Thread-safe — caller must hold channel.Lock while writing Message properties,
    /// then call this after releasing the lock.
    /// </summary>
    public void NotifyChannelUpdated(string portName)
    {
        if (!_channelsByPortName.TryGetValue(portName, out var channel) || !channel.IsSubscribed)
        {
            return;
        }

        channel.LastUpdateTime = DateTime.Now;

        channel.RecordHistory("RECEIVED");
    }

    /// <summary>
    /// Sets a callback invoked when the Send button is clicked for a queuing source channel.
    /// </summary>
    public void SetSendCallback(Action<object> callback)
    {
        _sendCallback = callback;
    }

    /// <summary>
    /// Refreshes the data grid for all subscribed channels that have open detail windows.
    /// Must be called from the UI thread or via Invoke.
    /// </summary>
    public void RefreshAll()
    {
        foreach (var form in _openDetailForms.Values)
        {
            form.RefreshGrid();
        }
    }

    /// <summary>
    /// Refreshes the data grid for a specific channel by port name.
    /// Must be called from the UI thread or via Invoke.
    /// </summary>
    public void RefreshChannel(string portName)
    {
        if (_openDetailForms.TryGetValue(portName, out var form))
        {
            form.RefreshGrid();
        }
    }

    private void PopulateTreeView()
    {
        PopulateTreeView("");
    }

    private void PopulateTreeView(string filter)
    {
        _suppressCheckEvents = true;
        _treeView.BeginUpdate();
        try
        {
            _treeView.Nodes.Clear();
            var hasFilter = !string.IsNullOrWhiteSpace(filter);
            var boldFont = _boldFont ??= new Font(_treeView.Font, FontStyle.Bold);
            var totalChannels = 0;

            // Group partitions by namespace
            var byNamespace = new Dictionary<string, List<PartitionNode>>(StringComparer.Ordinal);
            foreach (var partition in _partitions)
            {
                if (!byNamespace.TryGetValue(partition.Namespace, out var list))
                {
                    list = new List<PartitionNode>();
                    byNamespace[partition.Namespace] = list;
                }

                list.Add(partition);
            }

            // Create a namespace node per group
            foreach (var (ns, nsPartitions) in byNamespace)
            {
                var nsNode = new TreeNode(ns)
                {
                    NodeFont = boldFont,
                    ToolTipText = "Msg namespace"
                };

                foreach (var partition in nsPartitions)
                {
                    var partNode = new TreeNode(partition.Name)
                    {
                        Tag = partition,
                        ToolTipText = "Check individual channels to subscribe"
                    };

                    foreach (var channel in partition.Channels)
                    {
                        if (hasFilter)
                        {
                            var matchText = $"{channel.ChannelName} {channel.PortName} {channel.PortType} {channel.Direction}";
                            if (!matchText.Contains(filter, StringComparison.OrdinalIgnoreCase))
                            {
                                continue;
                            }
                        }

                        var dirPrefix = channel.Direction == "source" ? "[O]" : "[I]";
                        var chNode = new TreeNode($"{dirPrefix} {channel.ChannelName} ({channel.PortType})")
                        {
                            Tag = channel,
                            Checked = channel.IsSubscribed
                        };

                        ApplyChannelNodeStyle(chNode, channel);

                        _channelsByPortName[channel.PortName] = channel;
                        partNode.Nodes.Add(chNode);
                        totalChannels++;
                    }

                    if (partNode.Nodes.Count > 0)
                    {
                        nsNode.Nodes.Add(partNode);
                    }
                }

                if (nsNode.Nodes.Count > 0)
                {
                    _treeView.Nodes.Add(nsNode);
                }
            }

            // Smart expand: full expand for small trees, namespace-only for large
            if (totalChannels < 200)
            {
                _treeView.ExpandAll();
            }
            else
            {
                foreach (TreeNode nsNode in _treeView.Nodes)
                {
                    nsNode.Expand();
                }
            }
        }
        finally
        {
            _treeView.EndUpdate();
            _suppressCheckEvents = false;
        }
    }

    /// <summary>
    /// Applies color and font styling to a channel tree node.
    /// </summary>
    private static void ApplyChannelNodeStyle(TreeNode node, ChannelNode channel)
    {
        // Direction coloring
        node.ForeColor = channel.Direction == "source" ? Color.DarkGreen : Color.DarkBlue;

        // Queuing channels get italic; subscribed get bold
        var style = FontStyle.Regular;
        if (channel.PortType == PortType.Queuing)
        {
            style |= FontStyle.Italic;
        }

        if (channel.IsSubscribed)
        {
            style |= FontStyle.Bold;
        }

        if (style != FontStyle.Regular)
        {
            node.NodeFont = new Font(node.TreeView?.Font ?? SystemFonts.DefaultFont, style);
        }
        else
        {
            node.NodeFont = null;
        }
    }

    private void ActivateChannel(ChannelNode channel)
    {
        try
        {
            channel.Instance = Activator.CreateInstance(channel.ChannelType);
            channel.Message = channel.GetMessageFromInstance();
            channel.IsSubscribed = true;
            channel.LastUpdateTime = null;
            InvalidateSubscriptionCaches();
            ChannelSubscriptionChanged?.Invoke(channel, true);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Failed to activate channel '{channel.PortName}':\n{ex.Message}",
                "Activation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            channel.Instance = null;
            channel.Message = null;
            channel.IsSubscribed = false;
        }
    }

    private void DeactivateChannel(ChannelNode channel)
    {
        // Close detail form if open
        if (_openDetailForms.TryGetValue(channel.PortName, out var form))
        {
            form.Close();
            _openDetailForms.Remove(channel.PortName);
        }

        channel.Instance = null;
        channel.Message = null;
        channel.IsSubscribed = false;
        channel.LastUpdateTime = null;
        channel.MessageHistory.Clear();
        channel.MessageHistoryGeneration++;
        InvalidateSubscriptionCaches();
        ChannelSubscriptionChanged?.Invoke(channel, false);
    }

    private void InvalidateSubscriptionCaches()
    {
        _subscribedCache = null;
        _subscribedSourceCache = null;
        _subscribedDestCache = null;
    }

    private void OpenDetailForm(ChannelNode channel)
    {
        if (!channel.IsSubscribed)
        {
            return;
        }

        // If already open, bring to front
        if (_openDetailForms.TryGetValue(channel.PortName, out var existing))
        {
            existing.BringToFront();
            existing.Focus();
            return;
        }

        var portName = channel.PortName;
        var timerOffset = (_openDetailForms.Count % 3) * 33;
        var form = new ChannelDetailForm(channel, _sendCallback, _refreshTimer.Interval, timerOffset);
        form.FormClosed += (_, _) =>
        {
            _openDetailForms.Remove(portName);
            form.Dispose();
        };
        _openDetailForms[portName] = form;
        form.Show(this);
        SetActionStatus($"Opened {portName}");
    }

    private void CloseAllDetailForms()
    {
        foreach (var form in _openDetailForms.Values.ToList())
        {
            form.Close();
        }

        _openDetailForms.Clear();
    }

    /// <summary>
    /// Updates the subscription count in the status bar.
    /// </summary>
    private void UpdateSubscriptionStatus()
    {
        var total = _channelsByPortName.Count;
        var subscribed = _channelsByPortName.Values.Count(c => c.IsSubscribed);
        _statusLabelSubscribed.Text = $"Subscribed: {subscribed}/{total} channels";
    }

    /// <summary>
    /// Sets the action status text on the right side of the status bar.
    /// </summary>
    private void SetActionStatus(string text)
    {
        _statusLabelAction.Text = text;
    }

    // --- State persistence (#11) ---

    private static string StateFilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "A653PortViewer", "state.json");

    private void SaveState()
    {
        try
        {
            var state = new AppState
            {
                WindowX = Location.X,
                WindowY = Location.Y,
                WindowWidth = Size.Width,
                WindowHeight = Size.Height,
                SubscribedPorts = _channelsByPortName.Values
                    .Where(c => c.IsSubscribed)
                    .Select(c => c.PortName)
                    .ToList(),
                ChannelData = SaveChannelData(),
                HistoryLimits = SaveHistoryLimits()
            };

            var dir = Path.GetDirectoryName(StateFilePath)!;
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            var json = JsonSerializer.Serialize(state, JsonOptions);
            File.WriteAllText(StateFilePath, json);
        }
        catch
        {
            // Best-effort save; do not crash on state persistence failure
        }
    }

    private void RestoreState()
    {
        try
        {
            if (!File.Exists(StateFilePath))
            {
                return;
            }

            var json = File.ReadAllText(StateFilePath);
            var state = JsonSerializer.Deserialize<AppState>(json);
            if (state is null)
            {
                return;
            }

            // Restore window position/size only — no DLL loading
            if (state.WindowWidth > 0 && state.WindowHeight > 0)
            {
                StartPosition = FormStartPosition.Manual;
                Location = new Point(state.WindowX, state.WindowY);
                Size = new Size(state.WindowWidth, state.WindowHeight);
            }
        }
        catch
        {
            // Best-effort restore
        }
    }

    private void RestoreSubscriptionsFromState()
    {
        try
        {
            if (!File.Exists(StateFilePath))
            {
                return;
            }

            var json = File.ReadAllText(StateFilePath);
            var state = JsonSerializer.Deserialize<AppState>(json);
            if (state is null)
            {
                return;
            }

            if (state.SubscribedPorts is { Count: > 0 })
            {
                RestoreSubscriptions(state.SubscribedPorts);
            }

            if (state.ChannelData is { Count: > 0 })
            {
                RestoreChannelData(state.ChannelData);
            }

            if (state.HistoryLimits is { Count: > 0 })
            {
                RestoreHistoryLimits(state.HistoryLimits);
            }
        }
        catch
        {
            // Best-effort restore
        }
    }

    private void RestoreSubscriptions(List<string> portNames)
    {
        var portNameSet = new HashSet<string>(portNames, StringComparer.Ordinal);

        _suppressCheckEvents = true;
        try
        {
            foreach (TreeNode nsNode in _treeView.Nodes)
            {
                foreach (TreeNode partNode in nsNode.Nodes)
                {
                    foreach (TreeNode chNode in partNode.Nodes)
                    {
                        if (chNode.Tag is ChannelNode channel && portNameSet.Contains(channel.PortName))
                        {
                            ActivateChannel(channel);
                            if (channel.IsSubscribed)
                            {
                                chNode.Checked = true;
                                ApplyChannelNodeStyle(chNode, channel);
                            }
                        }
                    }
                }
            }
        }
        finally
        {
            _suppressCheckEvents = false;
        }

        UpdateSubscriptionStatus();
    }

    private Dictionary<string, Dictionary<string, string>> SaveChannelData()
    {
        var data = new Dictionary<string, Dictionary<string, string>>();

        foreach (var channel in _channelsByPortName.Values)
        {
            if (!channel.IsSubscribed || channel.Direction != "source" || channel.Message is null)
            {
                continue;
            }

            // Use snapshot if available (no lock needed)
            var snapshot = channel.LastSnapshot;
            if (snapshot is not null && snapshot.Count > 0)
            {
                data[channel.PortName] = new Dictionary<string, string>(snapshot, StringComparer.Ordinal);
                continue;
            }

            // Fallback: lock and read directly
            var fields = new Dictionary<string, string>();
            lock (channel.Lock)
            {
                foreach (var field in channel.Fields)
                {
                    if (field.IsNested || field.GetParentObject is null)
                    {
                        continue;
                    }

                    var parent = field.GetParentObject(channel.Message);
                    if (parent is null)
                    {
                        continue;
                    }

                    if (field.CompiledGetter is null)
                    {
                        continue;
                    }

                    var value = field.CompiledGetter(parent);
                    if (value is not null)
                    {
                        fields[field.DisplayName] = value.ToString() ?? "";
                    }
                }
            }

            if (fields.Count > 0)
            {
                data[channel.PortName] = fields;
            }
        }

        return data;
    }

    private void RestoreChannelData(Dictionary<string, Dictionary<string, string>> data)
    {
        foreach (var (portName, fields) in data)
        {
            if (!_channelsByPortName.TryGetValue(portName, out var channel) ||
                !channel.IsSubscribed || channel.Direction != "source" || channel.Message is null)
            {
                continue;
            }

            lock (channel.Lock)
            {
                foreach (var field in channel.Fields)
                {
                    if (field.IsNested || field.GetParentObject is null)
                    {
                        continue;
                    }

                    if (!fields.TryGetValue(field.DisplayName, out var text))
                    {
                        continue;
                    }

                    var parent = field.GetParentObject(channel.Message);
                    if (parent is null)
                    {
                        continue;
                    }

                    try
                    {
                        if (field.CompiledSetter is null)
                        {
                            continue;
                        }

                        var converted = Convert.ChangeType(text, field.FieldType);
                        field.CompiledSetter(parent, converted);
                    }
                    catch
                    {
                        // Skip fields that can't be restored
                    }
                }
            }

            channel.BuildSnapshot();
        }
    }

    private Dictionary<string, int> SaveHistoryLimits()
    {
        var limits = new Dictionary<string, int>();
        foreach (var channel in _channelsByPortName.Values)
        {
            if (channel.IsSubscribed)
            {
                limits[channel.PortName] = channel.MaxHistoryEntries;
            }
        }

        return limits;
    }

    private void RestoreHistoryLimits(Dictionary<string, int> limits)
    {
        foreach (var (portName, limit) in limits)
        {
            if (_channelsByPortName.TryGetValue(portName, out var channel) && channel.IsSubscribed)
            {
                channel.MaxHistoryEntries = limit;
            }
        }
    }

    // --- Event Handlers ---

    private void MainForm_Load(object? sender, EventArgs e)
    {
        RestoreState();
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        SaveState();
    }

    private void TxtFilter_TextChanged(object? sender, EventArgs e)
    {
        PopulateTreeView(_txtFilter.Text);
    }

    private void LoadDllMenuItem_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Filter = "DLL files (*.dll)|*.dll|All files (*.*)|*.*",
            Title = "Select A653 Msg DLL"
        };

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            LoadDll(dialog.FileName);
        }
    }

    private void TreeView_BeforeCheck(object? sender, TreeViewCancelEventArgs e)
    {
        if (_suppressCheckEvents)
        {
            return;
        }

        // Only channel nodes (ChannelNode tag) are checkable
        if (e.Node?.Tag is not ChannelNode)
        {
            e.Cancel = true;
        }
    }

    private void TreeView_AfterCheck(object? sender, TreeViewEventArgs e)
    {
        if (_suppressCheckEvents)
        {
            return;
        }

        if (e.Node?.Tag is not ChannelNode channel)
        {
            return;
        }

        if (e.Node.Checked)
        {
            ActivateChannel(channel);

            // If activation failed, uncheck the node
            if (!channel.IsSubscribed)
            {
                _suppressCheckEvents = true;
                e.Node.Checked = false;
                _suppressCheckEvents = false;
            }
        }
        else
        {
            DeactivateChannel(channel);
        }

        // #7 Update font style on check/uncheck
        ApplyChannelNodeStyle(e.Node, channel);
        UpdateSubscriptionStatus();
    }

    private void TreeView_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        if (e.Node?.Tag is ChannelNode channel)
        {
            OpenDetailForm(channel);
        }
    }

    private void BtnUnsubscribeAll_Click(object? sender, EventArgs e)
    {
        _suppressCheckEvents = true;
        try
        {
            foreach (TreeNode nsNode in _treeView.Nodes)
            {
                foreach (TreeNode partNode in nsNode.Nodes)
                {
                    foreach (TreeNode chNode in partNode.Nodes)
                    {
                        if (chNode.Tag is ChannelNode channel && channel.IsSubscribed)
                        {
                            DeactivateChannel(channel);
                            chNode.Checked = false;
                            ApplyChannelNodeStyle(chNode, channel);
                        }
                    }
                }
            }
        }
        finally
        {
            _suppressCheckEvents = false;
        }

        UpdateSubscriptionStatus();
        SetActionStatus("Unsubscribed all channels");
    }

    private void RefreshTimer_Tick(object? sender, EventArgs e)
    {
        // Timer tick exists for detail form auto-refresh (their own timers handle it).
        // No-op here — LastUpdateTime is set by the msgComm thread when data arrives.
    }

}

/// <summary>
/// Serializable application state for save/restore across sessions.
/// </summary>
internal sealed class AppState
{
    public int WindowX { get; set; }
    public int WindowY { get; set; }
    public int WindowWidth { get; set; }
    public int WindowHeight { get; set; }
    public List<string> SubscribedPorts { get; set; } = new List<string>();
    public Dictionary<string, Dictionary<string, string>> ChannelData { get; set; } = new Dictionary<string, Dictionary<string, string>>();
    public Dictionary<string, int> HistoryLimits { get; set; } = new Dictionary<string, int>();
}
