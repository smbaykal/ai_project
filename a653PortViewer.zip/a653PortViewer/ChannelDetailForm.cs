using System.Text;
using System.Text.Json;
using A653PortViewer.Reflection;

namespace A653PortViewer;

/// <summary>
/// Standalone window showing the detail view for a single channel port.
/// Uses virtual-mode DataGridView for O(visible) performance regardless of total field count.
/// </summary>
public sealed class ChannelDetailForm : Form
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    private readonly ChannelNode _channel;
    private readonly Action<object>? _sendCallback;
    private readonly System.Windows.Forms.Timer _refreshTimer;
    private readonly System.Windows.Forms.Timer _filterDebounceTimer;
    private readonly List<FieldNode> _allLeafFields = new List<FieldNode>();
    private List<FieldNode> _visibleFields = new List<FieldNode>();
    private HashSet<int> _selectedValueRows = new HashSet<int>();

    // Cached values for skip-unchanged (indexed by _visibleFields position)
    private string[] _cachedValues = Array.Empty<string>();
    private long _lastSeenGeneration;

    // Controls
    private readonly Label _lblLastUpdate;
    private readonly TextBox _txtFieldFilter;
    private readonly DataGridView _dataGridView;
    private readonly Button _btnSend;
    private readonly Button _btnClear;
    private readonly Button _btnExport;
    private readonly Button _btnImport;
    private readonly Button _btnHistory;
    private readonly TextBox _txtHistoryLimit;
    private readonly Label _lblSendStatus;
    private readonly System.Windows.Forms.Timer _sendStatusTimer;
    private readonly TextBox _txtLog;

    private const int MaxLogLines = 100;
    private const int ColFieldName = 0;
    private const int ColType = 1;
    private const int ColValue = 2;
    private const int ColRange = 3;

    public ChannelDetailForm(ChannelNode channel, Action<object>? sendCallback, int refreshIntervalMs, int timerOffsetMs = 0)
    {
        _channel = channel;
        _sendCallback = sendCallback;

        foreach (var f in channel.Fields)
        {
            if (!f.IsNested)
            {
                _allLeafFields.Add(f);
            }
        }

        _visibleFields = _allLeafFields;

        // --- Window setup ---
        var dirArrow = channel.Direction == "source" ? "\u2192" : "\u2190";
        Text = $"{channel.PortName}  ({channel.PortType}, {channel.Direction} {dirArrow})";
        Size = new Size(650, 640);
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(420, 400);

        // --- Header panel ---
        var headerPanel = new Panel { Dock = DockStyle.Top, Height = 130, Padding = new Padding(8) };

        var lblPortName = new Label
        {
            Text = channel.PortName,
            AutoSize = true,
            Font = new Font("Segoe UI", 11f, FontStyle.Bold),
            Location = new Point(8, 8)
        };
        var lblPortType = new Label { Text = $"Port Type: {channel.PortType}", AutoSize = true, Location = new Point(8, 34) };
        var lblDirection = new Label { Text = $"Direction: {channel.Direction}", AutoSize = true, Location = new Point(180, 34) };
        var lblMaxMessageSize = new Label { Text = $"Max Size: {channel.MaxMessageSize} bytes", AutoSize = true, Location = new Point(8, 54) };

        var extraParts = new List<string>();
        if (channel.RefreshPeriodNs.HasValue)
        {
            extraParts.Add($"Refresh: {channel.RefreshPeriodNs.Value / 1_000_000.0:F1} ms");
        }

        if (channel.MaxNbMessage.HasValue)
        {
            extraParts.Add($"Queue Depth: {channel.MaxNbMessage.Value}");
        }

        if (channel.QueuingDiscipline != QueuingDiscipline.None)
        {
            extraParts.Add($"Discipline: {channel.QueuingDiscipline}");
        }

        var lblExtraInfo = new Label { Text = string.Join("  |  ", extraParts), AutoSize = true, Location = new Point(8, 74) };
        _lblLastUpdate = new Label
        {
            Text = "",
            AutoSize = true,
            Location = new Point(8, 94),
            ForeColor = SystemColors.GrayText
        };

        var lblHistoryLimit = new Label { Text = "History:", AutoSize = true, Location = new Point(8, 114) };
        _txtHistoryLimit = new TextBox
        {
            Text = channel.MaxHistoryEntries.ToString(),
            Width = 50,
            Location = new Point(60, 111)
        };
        _txtHistoryLimit.Leave += TxtHistoryLimit_Changed;
        _txtHistoryLimit.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; TxtHistoryLimit_Changed(null, EventArgs.Empty); } };

        var toolTip = new ToolTip();
        var lblHistoryInfo = new Label
        {
            Text = "(-1=disabled (default), 0=unlimited, N=keep last N)",
            AutoSize = true,
            Location = new Point(116, 114),
            ForeColor = SystemColors.GrayText
        };
        toolTip.SetToolTip(lblHistoryInfo, "Number of messages to keep in history.\n-1 = disabled (default)\n0 = unlimited (grows until cleared)\nN = keep last N entries");
        toolTip.SetToolTip(_txtHistoryLimit, "-1=disabled (default), 0=unlimited, N=keep last N");

        headerPanel.Controls.AddRange(new Control[] { lblPortName, lblPortType, lblDirection, lblMaxMessageSize, lblExtraInfo, _lblLastUpdate, lblHistoryLimit, _txtHistoryLimit, lblHistoryInfo });

        // --- Filter panel ---
        var filterPanel = new Panel { Dock = DockStyle.Top, Height = 30, Padding = new Padding(4, 4, 4, 2) };
        _txtFieldFilter = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Filter fields..." };
        _txtFieldFilter.TextChanged += TxtFieldFilter_TextChanged;
        filterPanel.Controls.Add(_txtFieldFilter);

        _filterDebounceTimer = new System.Windows.Forms.Timer { Interval = 200 };
        _filterDebounceTimer.Tick += (_, _) =>
        {
            _filterDebounceTimer.Stop();
            ApplyFilter(_txtFieldFilter.Text);
        };

        // --- Button panel ---
        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 56,
            Padding = new Padding(4),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true
        };

        _btnSend = new Button
        {
            Text = "Send (Ctrl+Enter)",
            Width = 120,
            Visible = channel.Direction == "source" && channel.PortType == PortType.Queuing
        };
        _btnSend.Click += BtnSend_Click;

        _btnClear = new Button { Text = "Clear (Ctrl+Shift+C)", Width = 130 };
        _btnClear.Click += BtnClear_Click;

        _btnExport = new Button { Text = "Export", Width = 80 };
        _btnExport.Click += BtnExport_Click;

        _btnImport = new Button { Text = "Import", Width = 80, Visible = channel.Direction == "source" };
        _btnImport.Click += BtnImport_Click;

        _btnHistory = new Button { Text = "History", Width = 80 };
        _btnHistory.Click += BtnHistory_Click;

        _lblSendStatus = new Label
        {
            AutoSize = true,
            Text = "",
            Padding = new Padding(8, 6, 0, 0)
        };

        buttonPanel.Controls.AddRange(new Control[] { _btnSend, _btnClear, _btnExport, _btnImport, _btnHistory, _lblSendStatus });

        _sendStatusTimer = new System.Windows.Forms.Timer { Interval = 3000 };
        _sendStatusTimer.Tick += (_, _) =>
        {
            _lblSendStatus.Text = "";
            _sendStatusTimer.Stop();
        };

        // --- Message log panel ---
        _txtLog = new TextBox
        {
            Dock = DockStyle.Bottom,
            Height = 80,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Font = new Font("Consolas", 8.25f)
        };

        // --- Data grid (virtual mode) ---
        _dataGridView = new DataGridView
        {
            Dock = DockStyle.Fill,
            VirtualMode = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.CellSelect,
            MultiSelect = true,
            EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2
        };
        _dataGridView.CellValueNeeded += DataGridView_CellValueNeeded;
        _dataGridView.CellValuePushed += DataGridView_CellValuePushed;
        _dataGridView.CellBeginEdit += DataGridView_CellBeginEdit;
        _dataGridView.CellEndEdit += DataGridView_CellEndEdit;

        _dataGridView.Columns.AddRange(
            new DataGridViewTextBoxColumn { Name = "FieldName", HeaderText = "Field", ReadOnly = true, FillWeight = 35 },
            new DataGridViewTextBoxColumn { Name = "Type", HeaderText = "Type", ReadOnly = true, FillWeight = 15 },
            new DataGridViewTextBoxColumn { Name = "Value", HeaderText = "Value", FillWeight = 25 },
            new DataGridViewTextBoxColumn { Name = "Range", HeaderText = "Range", ReadOnly = true, FillWeight = 25 }
        );

        // Read-only for destination channels
        if (channel.Direction != "source")
        {
            _dataGridView.Columns["Value"].ReadOnly = true;
        }

        // Context menu
        var gridContextMenu = new ContextMenuStrip();
        var copyValueItem = new ToolStripMenuItem("Copy Value");
        copyValueItem.Click += CopyValue_Click;
        var copyFieldNameItem = new ToolStripMenuItem("Copy Field Name");
        copyFieldNameItem.Click += CopyFieldName_Click;
        var copyAllItem = new ToolStripMenuItem("Copy All as Text");
        copyAllItem.Click += CopyAll_Click;
        gridContextMenu.Items.AddRange(new ToolStripItem[] { copyValueItem, copyFieldNameItem, copyAllItem });
        _dataGridView.ContextMenuStrip = gridContextMenu;

        // --- Assemble ---
        Controls.Add(_dataGridView);
        Controls.Add(filterPanel);
        Controls.Add(_txtLog);
        Controls.Add(buttonPanel);
        Controls.Add(headerPanel);

        // --- Set virtual row count ---
        RebuildCachedValues();
        _dataGridView.RowCount = _visibleFields.Count;

        // --- Refresh timer ---
        _refreshTimer = new System.Windows.Forms.Timer { Interval = refreshIntervalMs };
        _refreshTimer.Tick += RefreshTimer_Tick;
        if (timerOffsetMs > 0)
        {
            var startDelay = new System.Windows.Forms.Timer { Interval = timerOffsetMs };
            startDelay.Tick += (_, _) => { startDelay.Stop(); startDelay.Dispose(); _refreshTimer.Start(); };
            startDelay.Start();
        }
        else
        {
            _refreshTimer.Start();
        }
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        if (keyData == (Keys.Control | Keys.Enter))
        {
            if (_btnSend.Visible)
            {
                BtnSend_Click(this, EventArgs.Empty);
            }

            return true;
        }

        if (keyData == (Keys.Control | Keys.Shift | Keys.C))
        {
            BtnClear_Click(this, EventArgs.Empty);
            return true;
        }

        return base.ProcessCmdKey(ref msg, keyData);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _refreshTimer.Stop();
        _refreshTimer.Dispose();
        _sendStatusTimer.Stop();
        _sendStatusTimer.Dispose();
        _filterDebounceTimer.Stop();
        _filterDebounceTimer.Dispose();
        _allLeafFields.Clear();
        _visibleFields = new List<FieldNode>();
        _cachedValues = Array.Empty<string>();
        base.OnFormClosed(e);
    }

    // --- Virtual mode: filtered index ---

    private void ApplyFilter(string filter)
    {
        if (string.IsNullOrWhiteSpace(filter))
        {
            _visibleFields = _allLeafFields;
        }
        else
        {
            _visibleFields = _allLeafFields
                .Where(f => f.DisplayName.Contains(filter, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        RebuildCachedValues();
        _dataGridView.RowCount = _visibleFields.Count;
        _dataGridView.Invalidate();
    }

    private void RebuildCachedValues()
    {
        _cachedValues = new string[_visibleFields.Count];
        if (_channel.Message is null)
        {
            return;
        }

        // Try snapshot first (no lock needed)
        var snapshot = _channel.LastSnapshot;
        if (snapshot is not null)
        {
            for (var i = 0; i < _visibleFields.Count; i++)
            {
                _cachedValues[i] = snapshot.TryGetValue(_visibleFields[i].DisplayName, out var val) ? val : "";
            }

            _lastSeenGeneration = _channel.SnapshotGeneration;
            return;
        }

        // Fallback: lock and read directly (first open before any snapshot exists)
        lock (_channel.Lock)
        {
            for (var i = 0; i < _visibleFields.Count; i++)
            {
                _cachedValues[i] = GetFieldValue(_visibleFields[i]);
            }
        }
    }

    /// <summary>
    /// Refreshes cached values from the channel's snapshot and invalidates only changed cells.
    /// No lock required — reads the snapshot reference atomically.
    /// </summary>
    public void RefreshGrid()
    {
        var gen = _channel.SnapshotGeneration;
        if (gen == _lastSeenGeneration)
        {
            // Update timestamp even when no data changed
            if (_channel.Direction == "destination" && _channel.LastUpdateTime.HasValue)
            {
                _lblLastUpdate.Text = $"Last update: {_channel.LastUpdateTime:HH:mm:ss.fff}";
            }

            return;
        }

        _lastSeenGeneration = gen;
        var snapshot = _channel.LastSnapshot;
        if (snapshot is null)
        {
            return;
        }

        for (var i = 0; i < _visibleFields.Count; i++)
        {
            if (snapshot.TryGetValue(_visibleFields[i].DisplayName, out var newVal)
                && newVal != _cachedValues[i])
            {
                _cachedValues[i] = newVal;
                _dataGridView.InvalidateCell(ColValue, i);
            }
        }

        if (_channel.Direction == "destination" && _channel.LastUpdateTime.HasValue)
        {
            _lblLastUpdate.Text = $"Last update: {_channel.LastUpdateTime:HH:mm:ss.fff}";
        }
    }

    // --- Virtual mode event handlers ---

    private void DataGridView_CellValueNeeded(object? sender, DataGridViewCellValueEventArgs e)
    {
        if (e.RowIndex < 0 || e.RowIndex >= _visibleFields.Count)
        {
            return;
        }

        var field = _visibleFields[e.RowIndex];
        e.Value = e.ColumnIndex switch
        {
            ColFieldName => field.DisplayName,
            ColType => field.FieldType.Name,
            ColValue => e.RowIndex < _cachedValues.Length ? _cachedValues[e.RowIndex] : "",
            ColRange => BuildRangeText(field),
            _ => null
        };
    }

    private void DataGridView_CellValuePushed(object? sender, DataGridViewCellValueEventArgs e)
    {
        if (e.ColumnIndex != ColValue || e.RowIndex < 0 || e.RowIndex >= _visibleFields.Count)
        {
            return;
        }

        // Store the pushed value in cache (actual model write happens in CellEndEdit)
        if (e.RowIndex < _cachedValues.Length)
        {
            _cachedValues[e.RowIndex] = e.Value?.ToString() ?? "";
        }
    }

    // --- Field access ---

    private void AddLog(string action)
    {
        var timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
        var entry = $"[{timestamp}] {action}";

        var lines = _txtLog.Lines;
        var newLines = new List<string>(lines.Length + 1) { entry };
        newLines.AddRange(lines);

        if (newLines.Count > MaxLogLines)
        {
            newLines.RemoveRange(MaxLogLines, newLines.Count - MaxLogLines);
        }

        _txtLog.Lines = newLines.ToArray();
    }

    private string GetFieldValue(FieldNode field)
    {
        if (_channel.Message is null || field.GetParentObject is null || field.CompiledGetter is null)
        {
            return "";
        }

        var parent = field.GetParentObject(_channel.Message);
        if (parent is null)
        {
            return "";
        }

        var value = field.CompiledGetter(parent);
        return value?.ToString() ?? "";
    }

    private void SetFieldValue(FieldNode field, string text)
    {
        if (_channel.Message is null || field.GetParentObject is null || field.CompiledSetter is null)
        {
            return;
        }

        var parent = field.GetParentObject(_channel.Message);
        if (parent is null)
        {
            return;
        }

        try
        {
            var converted = ConvertValue(text, field.FieldType);
            field.CompiledSetter(parent, converted);
        }
        catch (Exception)
        {
            // Parse error — grid reverts on next refresh
        }
    }

    private void SyncVisibleFieldsToMessage()
    {
        lock (_channel.Lock)
        {
            for (var i = 0; i < _visibleFields.Count; i++)
            {
                var val = i < _cachedValues.Length ? _cachedValues[i] : "";
                SetFieldValue(_visibleFields[i], val);
            }
        }
    }

    private static string BuildRangeText(FieldNode field)
    {
        var parts = new List<string>();
        if (field.Min is not null && field.Max is not null)
        {
            parts.Add($"[{field.Min} .. {field.Max}]");
        }

        if (field.Resolution is not null)
        {
            parts.Add($"res={field.Resolution}");
        }

        if (field.MaxLength.HasValue)
        {
            parts.Add($"max {field.MaxLength} chars");
        }

        if (field.ArrayLength.HasValue)
        {
            parts.Add($"[{field.ArrayLength}]");
        }

        return string.Join(", ", parts);
    }

    private static object? ConvertValue(string text, Type targetType)
    {
        if (targetType == typeof(string)) { return text; }
        if (targetType == typeof(float)) { return float.Parse(text); }
        if (targetType == typeof(double)) { return double.Parse(text); }
        if (targetType == typeof(int)) { return int.Parse(text); }
        if (targetType == typeof(uint)) { return uint.Parse(text); }
        if (targetType == typeof(long)) { return long.Parse(text); }
        if (targetType == typeof(ulong)) { return ulong.Parse(text); }
        if (targetType == typeof(short)) { return short.Parse(text); }
        if (targetType == typeof(ushort)) { return ushort.Parse(text); }
        if (targetType == typeof(byte)) { return byte.Parse(text); }
        if (targetType == typeof(sbyte)) { return sbyte.Parse(text); }
        if (targetType == typeof(bool)) { return bool.Parse(text); }
        if (targetType == typeof(char)) { return text.Length > 0 ? text[0] : '\0'; }
        return Convert.ChangeType(text, targetType);
    }

    // --- Event Handlers ---

    private void TxtHistoryLimit_Changed(object? sender, EventArgs e)
    {
        if (int.TryParse(_txtHistoryLimit.Text, out var limit))
        {
            _channel.MaxHistoryEntries = limit;

            // Trim existing history to new limit
            if (limit > 0 && _channel.MessageHistory.Count > limit)
            {
                _channel.MessageHistory.RemoveRange(0, _channel.MessageHistory.Count - limit);
                _channel.MessageHistoryGeneration++;
            }
        }
        else
        {
            _txtHistoryLimit.Text = _channel.MaxHistoryEntries.ToString();
        }
    }

    private void TxtFieldFilter_TextChanged(object? sender, EventArgs e)
    {
        _filterDebounceTimer.Stop();
        _filterDebounceTimer.Start();
    }

    private void RefreshTimer_Tick(object? sender, EventArgs e)
    {
        RefreshGrid();
    }

    private void DataGridView_CellBeginEdit(object? sender, DataGridViewCellCancelEventArgs e)
    {
        _selectedValueRows = new HashSet<int>();
        foreach (DataGridViewCell cell in _dataGridView.SelectedCells)
        {
            if (cell.ColumnIndex == ColValue)
            {
                _selectedValueRows.Add(cell.RowIndex);
            }
        }
    }

    private void DataGridView_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
    {
        if (_channel.Direction != "source")
        {
            return;
        }

        if (e.ColumnIndex != ColValue)
        {
            return;
        }

        var editedValue = e.RowIndex < _cachedValues.Length ? _cachedValues[e.RowIndex] : "";

        lock (_channel.Lock)
        {
            if (e.RowIndex < _visibleFields.Count)
            {
                var editedField = _visibleFields[e.RowIndex];
                SetFieldValue(editedField, editedValue);
                AddLog($"EDIT {editedField.DisplayName} = {editedValue}");
            }

            foreach (var rowIndex in _selectedValueRows)
            {
                if (rowIndex != e.RowIndex && rowIndex < _visibleFields.Count)
                {
                    var field = _visibleFields[rowIndex];
                    SetFieldValue(field, editedValue);
                    if (rowIndex < _cachedValues.Length)
                    {
                        _cachedValues[rowIndex] = GetFieldValue(field);
                    }

                    _dataGridView.InvalidateCell(ColValue, rowIndex);
                }
            }
        }

        _selectedValueRows = new HashSet<int>();

        // Update snapshot so UI refresh sees the edit immediately
        _channel.BuildSnapshot();

        // Record history for source sampling ports on edit
        if (_channel.PortType == PortType.Sampling)
        {
            _channel.RecordHistory("UPDATED");
        }
    }

    private void BtnSend_Click(object? sender, EventArgs e)
    {
        if (_channel.Instance is null)
        {
            return;
        }

        SyncVisibleFieldsToMessage();

        try
        {
            _sendCallback?.Invoke(_channel.Instance);
            _channel.RecordHistory("SENT");
            _lblSendStatus.ForeColor = Color.Green;
            _lblSendStatus.Text = $"Sent at {DateTime.Now:HH:mm:ss.fff}";
            AddLog("SEND");
        }
        catch (Exception ex)
        {
            _lblSendStatus.ForeColor = Color.Red;
            _lblSendStatus.Text = $"Send failed: {ex.Message}";
            AddLog($"SEND FAILED: {ex.Message}");
        }

        _sendStatusTimer.Stop();
        _sendStatusTimer.Start();
    }

    private void BtnClear_Click(object? sender, EventArgs e)
    {
        if (_channel.Instance is null)
        {
            return;
        }

        var result = MessageBox.Show("Reset all fields?", "Clear",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result != DialogResult.Yes)
        {
            return;
        }

        var newMessage = Activator.CreateInstance(_channel.MessageType);
        _channel.SetMessageOnInstance(newMessage);
        _channel.Message = newMessage;
        _channel.BuildSnapshot();
        RebuildCachedValues();
        _dataGridView.Invalidate();
        AddLog("CLEAR");
    }

    // --- JSON Export/Import ---

    private void BtnExport_Click(object? sender, EventArgs e)
    {
        var data = new Dictionary<string, string>();
        for (var i = 0; i < _visibleFields.Count; i++)
        {
            data[_visibleFields[i].DisplayName] = i < _cachedValues.Length ? _cachedValues[i] : "";
        }

        using var dialog = new SaveFileDialog
        {
            Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
            FileName = $"{_channel.PortName}.json"
        };

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            try
            {
                var json = JsonSerializer.Serialize(data, JsonOptions);
                File.WriteAllText(dialog.FileName, json);
                AddLog($"EXPORT to {Path.GetFileName(dialog.FileName)}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed:\n{ex.Message}", "Export Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void BtnImport_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*"
        };

        if (dialog.ShowDialog() != DialogResult.OK)
        {
            return;
        }

        try
        {
            var json = File.ReadAllText(dialog.FileName);
            var data = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
            if (data is null)
            {
                return;
            }

            lock (_channel.Lock)
            {
                for (var i = 0; i < _visibleFields.Count; i++)
                {
                    if (data.TryGetValue(_visibleFields[i].DisplayName, out var value))
                    {
                        SetFieldValue(_visibleFields[i], value);
                        if (i < _cachedValues.Length)
                        {
                            _cachedValues[i] = GetFieldValue(_visibleFields[i]);
                        }
                    }
                }
            }

            _channel.BuildSnapshot();
            _dataGridView.Invalidate();
            AddLog($"IMPORT from {Path.GetFileName(dialog.FileName)}");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Import failed:\n{ex.Message}", "Import Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // --- Copy context menu ---

    private void CopyValue_Click(object? sender, EventArgs e)
    {
        if (_dataGridView.CurrentCell is { ColumnIndex: ColValue, RowIndex: >= 0 } cell &&
            cell.RowIndex < _cachedValues.Length)
        {
            var text = _cachedValues[cell.RowIndex];
            if (!string.IsNullOrEmpty(text))
            {
                Clipboard.SetText(text);
            }
        }
    }

    private void CopyFieldName_Click(object? sender, EventArgs e)
    {
        if (_dataGridView.CurrentCell is { RowIndex: >= 0 } cell &&
            cell.RowIndex < _visibleFields.Count)
        {
            Clipboard.SetText(_visibleFields[cell.RowIndex].DisplayName);
        }
    }

    private void CopyAll_Click(object? sender, EventArgs e)
    {
        var sb = new StringBuilder();
        for (var i = 0; i < _visibleFields.Count; i++)
        {
            var val = i < _cachedValues.Length ? _cachedValues[i] : "";
            sb.AppendLine($"{_visibleFields[i].DisplayName} = {val}");
        }

        var text = sb.ToString();
        if (!string.IsNullOrEmpty(text))
        {
            Clipboard.SetText(text);
        }
    }

    // --- Message history ---

    private MessageHistoryForm? _historyForm;

    private void BtnHistory_Click(object? sender, EventArgs e)
    {
        if (_historyForm is not null && !_historyForm.IsDisposed)
        {
            _historyForm.BringToFront();
            _historyForm.Focus();
            return;
        }

        _historyForm = new MessageHistoryForm(_channel);
        _historyForm.FormClosed += (_, _) => _historyForm = null;
        _historyForm.Show(this);
    }

}
