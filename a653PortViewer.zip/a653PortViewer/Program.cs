using A653PortViewer.Reflection;

namespace A653PortViewer;

internal static class Program
{
    /// <summary>
    /// Main thread runs the comm loop. UI is spawned on a dedicated STA thread.
    /// </summary>
    static void Main(string[] args)
    {
        MainForm? form = null;
        var uiReady = new ManualResetEventSlim(false);

        var uiThread = new Thread(() =>
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            form = new MainForm();

            if (args.Length > 0 && File.Exists(args[0]))
            {
                form.LoadDll(args[0]);
            }
            else
            {
                form.LoadPartitions(
                    MsgAssemblyLoader.LoadAssembly(typeof(Avionics.NavigationPartition).Assembly));
            }

            uiReady.Set();
            Application.Run(form);
        })
        {
            Name = "UI",
            IsBackground = false
        };
        uiThread.SetApartmentState(ApartmentState.STA);
        uiThread.Start();

        uiReady.Wait();

        // Register event handlers from main thread (delegate assignments are thread-safe)
        RegisterEventHandlers(form!);

        // Main thread is now the comm loop
        MsgCommLoop(form!);
    }

    /// <summary>
    /// Registers subscription change and send callbacks on the form.
    /// Called from the main (comm) thread after UI is ready.
    /// </summary>
    private static void RegisterEventHandlers(MainForm form)
    {
        form.ChannelSubscriptionChanged += (channel, subscribed) =>
        {
            if (subscribed)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[MsgComm] Channel subscribed: {channel.PortName} ({channel.Direction})");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[MsgComm] Channel unsubscribed: {channel.PortName}");
            }
        };

        form.SetSendCallback(channelInstance =>
        {
            var msgProp = channelInstance.GetType().GetProperty("Message");
            if (msgProp is null) return;

            var message = msgProp.GetValue(channelInstance);
            System.Diagnostics.Debug.WriteLine(
                $"[MsgComm] Send requested, message type: {message?.GetType().Name}");
        });
    }

    /// <summary>
    /// Comm loop running on the main thread.
    /// Writes to destination ports (simulating received data) and reads from source ports.
    /// </summary>
    private static void MsgCommLoop(MainForm form)
    {
        uint sequence = 0;

        while (true)
        {
            Thread.Sleep(500); // Simulate 2 Hz data rate

            // --- Writing to a destination port (simulating received data) ---
            var destChannel = form.GetChannel("Navigation_I_FMAlerts");
            if (destChannel is { IsSubscribed: true, Message: not null })
            {
                lock (destChannel.Lock)
                {
                    foreach (var field in destChannel.Fields)
                    {
                        if (field.IsNested || field.CompiledSetter is null) continue;

                        var parent = field.GetParentObject?.Invoke(destChannel.Message);
                        if (parent is null) continue;

                        if (field.DisplayName == "Sequence" && field.FieldType == typeof(uint))
                        {
                            field.CompiledSetter(parent, sequence);
                        }
                    }
                }

                form.NotifyChannelUpdated(destChannel.PortName);
            }

            // --- Reading from a source port (simulating data to transmit) ---
            var srcChannel = form.GetChannel("Navigation_O_NavPosition");
            if (srcChannel is { IsSubscribed: true, Message: not null })
            {
                lock (srcChannel.Lock)
                {
                    foreach (var field in srcChannel.Fields)
                    {
                        if (field.IsNested || field.CompiledGetter is null) continue;

                        var parent = field.GetParentObject?.Invoke(srcChannel.Message);
                        if (parent is null) continue;

                        var value = field.CompiledGetter(parent);
                        System.Diagnostics.Debug.WriteLine(
                            $"[MsgComm] Read {srcChannel.PortName}.{field.DisplayName} = {value}");
                    }
                }
            }

            sequence++;
        }
    }
}
