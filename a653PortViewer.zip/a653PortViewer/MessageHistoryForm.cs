using System.Text;
using System.Text.Json;
using A653PortViewer.Reflection;

namespace A653PortViewer;

/// <summary>
/// Separate window showing all sent/received messages for a channel with timestamps.
/// Uses virtual-mode DataGridView to avoid allocating row objects on every refresh.
/// </summary>
public sealed class MessageHistoryForm : Form
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly Color SentColor = Color.FromArgb(232, 245, 233);
    private static readonly Color ReceivedColor = Color.FromArgb(227, 242, 253);

    private readonly ChannelNode _channel;
    private readonly DataGridView _grid;
    private readonly System.Windows.Forms.Timer _refreshTimer;
    private readonly List<string> _fieldNames = new List<string>();
    private int _lastGeneration;

    // Snapshot of history reversed (newest first) — rebuilt only when generation changes
    private List<MessageHistoryEntry> _displayList = new List<MessageHistoryEntry>();

    public MessageHistoryForm(ChannelNode channel)
    {
        _channel = channel;

        Text = $"{channel.PortName} \u2014 Message History";
        Size = new Size(900, 500);
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(400, 250);

        // Collect leaf field names
        foreach (var field in channel.Fields)
        {
            if (!field.IsNested)
            {
                _fieldNames.Add(field.DisplayName);
            }
        }

        // --- Button panel ---
        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 36,
            Padding = new Padding(4),
            FlowDirection = FlowDirection.LeftToRight
        };

        var btnClear = new Button { Text = "Clear", Width = 80 };
        btnClear.Click += BtnClear_Click;
        var btnExport = new Button { Text = "Export", Width = 80 };
        btnExport.Click += BtnExport_Click;

        buttonPanel.Controls.AddRange(new Control[] { btnClear, btnExport });

        // --- Grid (virtual mode) ---
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            VirtualMode = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            RowHeadersVisible = false,
            ReadOnly = true,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false
        };
        _grid.CellValueNeeded += Grid_CellValueNeeded;
        _grid.CellFormatting += Grid_CellFormatting;

        // Fixed columns
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Num", HeaderText = "#", Width = 40 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Timestamp", HeaderText = "Timestamp", Width = 110 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Direction", HeaderText = "Dir", Width = 60 });

        // One column per leaf field
        foreach (var name in _fieldNames)
        {
            _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = name });
        }

        Controls.Add(_grid);
        Controls.Add(buttonPanel);

        // Initial load
        RebuildDisplayList();

        // Poll for changes
        _refreshTimer = new System.Windows.Forms.Timer { Interval = 200 };
        _refreshTimer.Tick += (_, _) =>
        {
            if (_channel.MessageHistoryGeneration != _lastGeneration)
            {
                RebuildDisplayList();
            }
        };
        _refreshTimer.Start();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _refreshTimer.Stop();
        _refreshTimer.Dispose();
        base.OnFormClosed(e);
    }

    private void RebuildDisplayList()
    {
        _lastGeneration = _channel.MessageHistoryGeneration;

        var history = _channel.MessageHistory;
        _displayList = new List<MessageHistoryEntry>(history.Count);
        for (var i = history.Count - 1; i >= 0; i--)
        {
            _displayList.Add(history[i]);
        }

        _grid.RowCount = _displayList.Count;
        _grid.Invalidate();
    }

    private void Grid_CellValueNeeded(object? sender, DataGridViewCellValueEventArgs e)
    {
        if (e.RowIndex < 0 || e.RowIndex >= _displayList.Count)
        {
            return;
        }

        var entry = _displayList[e.RowIndex];
        var colName = _grid.Columns[e.ColumnIndex].Name;

        if (colName == "Num")
        {
            e.Value = (_displayList.Count - e.RowIndex).ToString();
        }
        else if (colName == "Timestamp")
        {
            e.Value = entry.Timestamp.ToString("HH:mm:ss.fff");
        }
        else if (colName == "Direction")
        {
            e.Value = entry.Direction;
        }
        else if (entry.Fields.TryGetValue(colName, out var val))
        {
            e.Value = val;
        }
    }

    private void Grid_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.RowIndex < 0 || e.RowIndex >= _displayList.Count)
        {
            return;
        }

        e.CellStyle!.BackColor = _displayList[e.RowIndex].Direction == "SENT" ? SentColor : ReceivedColor;
    }

    private void BtnClear_Click(object? sender, EventArgs e)
    {
        _channel.MessageHistory.Clear();
        _channel.MessageHistoryGeneration++;
        RebuildDisplayList();
    }

    private void BtnExport_Click(object? sender, EventArgs e)
    {
        using var dialog = new SaveFileDialog
        {
            Filter = "JSON files (*.json)|*.json|CSV files (*.csv)|*.csv|All files (*.*)|*.*",
            FileName = $"{_channel.PortName}_history"
        };

        if (dialog.ShowDialog() != DialogResult.OK)
        {
            return;
        }

        try
        {
            if (dialog.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                ExportCsv(dialog.FileName);
            }
            else
            {
                ExportJson(dialog.FileName);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Export failed:\n{ex.Message}", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ExportJson(string path)
    {
        var json = JsonSerializer.Serialize(_channel.MessageHistory, JsonOptions);
        File.WriteAllText(path, json);
    }

    private void ExportCsv(string path)
    {
        var sb = new StringBuilder();

        sb.Append("#,Timestamp,Direction");
        foreach (var name in _fieldNames)
        {
            sb.Append(',');
            sb.Append(name);
        }
        sb.AppendLine();

        for (var i = 0; i < _channel.MessageHistory.Count; i++)
        {
            var entry = _channel.MessageHistory[i];
            sb.Append(i + 1);
            sb.Append(',');
            sb.Append(entry.Timestamp.ToString("HH:mm:ss.fff"));
            sb.Append(',');
            sb.Append(entry.Direction);

            foreach (var name in _fieldNames)
            {
                sb.Append(',');
                if (entry.Fields.TryGetValue(name, out var val))
                {
                    sb.Append(val);
                }
            }
            sb.AppendLine();
        }

        File.WriteAllText(path, sb.ToString());
    }
}
